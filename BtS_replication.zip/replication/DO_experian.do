/*------------------------------------------------------------------------------
Rochester Bridges to Success
	*Started: 03/01/22
	*Updated: 04/01/22
	*Author: Tim Spilde
	* This do file takes cleaned cohort 1 data and adds/labels Experain data. There are six different potential baseline groups in cohort 1. The experian data is merged individualy so that the treatment quarters align. Treatment starts in quarter 17 for all observations.
	
	* This file is constructed to use locals throughout this file. The only updating that needs to be done is to update the global "quarters" whenever a new quarter is pulled.
------------------------------*/
global quarters 201406 201409 201412 201503 201506 201509 201512 201603 201606 201609 201612 201703 201706 201709 201712 201803 201806 201809 201812 201903 201906 /// 
201909  201912 202003 202006 202009 202012 202103 202106 202109 202112 202203 202206

global controls female quarterly_r_earnings married_clean white black other hispanic ///
hs_GED_clean college_clean some_college_clean nohs_clean
global fe month_year randomization_group 

global outcomes bankcard_total_balance credit_score prime_credit all_total_balance has_debt  has_cc_debt mortgage_total_balance all_balance_excl_mta
global outcomes_continuous bankcard_total_balance credit_score all_total_balance mortgage_total_balance all_balance_excl_mta
global outcomes_binary prime_credit has_debt  has_cc_debt
*******************************************************************************
* Get baseline survey data
*******************************************************************************
use "${dta_loc}/Complete Clean", clear
gen cohort = 1
append using "${dta_loc}/Complete Clean C2", force
replace cohort = 2 if missing(cohort)
replace treat_status = treatment_final if missing(treat_status)

keeporder experian_id baselinedate treat_status working_clean cohort $controls $fe
tostring experian_id, replace
drop if experian_id == "."
tempfile bline_survey
save `bline_survey'
*******************************************************************************
* Get baseline survey data
*******************************************************************************
* Create a file of all experian files. Generate the quarter variable so we know which data is associated with which quarter.

cd "${raw_experian}"
use "Bridges_Experian_201406.dta", clear
qui gen quarter = "201406"

 foreach var in $quarters {

else if	inrange(`var', 201409,201912) {
qui append using "Bridges_Experian_`var'.dta", force 
qui replace quarter = "`var'" if missing(quarter)
}

else if	inrange(`var', 202003,202112) {
qui append using "BS1_fromexperian_`var'.dta", force 
qui append using "BS2_fromexperian_`var'.dta", force 
qui replace quarter = "`var'" if missing(quarter) 
 }
 }
 
gen experian_id = leoid
replace experian_id = subinstr(experian_id,"BS1-","", .)
replace experian_id = subinstr(experian_id,"BS2-","", .)
drop  credit_score prime_credit all_total_balance bankcard_total_balance mortgage_total_balance
qui gen sample = !missing(vantage_v4_score)

*******************************************************************************
* Generate Outcomes
*******************************************************************************
* This code comes from Patrick and was used in the P study.
* Credit score
recode vantage_v4_score (1 4=.), gen(credit_score)
label var credit_score "Vantage Credit Score"

* Prime credit score
gen prime_credit = credit_score>=650 if !missing(credit_score)
label var prime_credit "Prime Credit Score (\\\geq 650)"

* Total Balance
recode p13_all5020 (999999991/999999999=0), gen(all_total_balance)
label var all_total_balance "Total Balance on All Open Trades"

* Has any debt
gen has_debt = all_total_balance>0 if ~missing(all_total_balance)
label var has_debt "Has Debt"

* Total CC Balance
recode p13_bca5020 (999999991/999999999=0), gen(bankcard_total_balance)
label var bankcard_total_balance "Total Amount of Credit Card Debt"

* Has CC Debt
gen has_cc_debt = bankcard_total_balance>0 if ~missing(bankcard_total_balance)
label var has_cc_debt "Has Credit Card Debt"

* Total Mortgage Balance
recode p13_mta5020 (999999991/999999999=0), gen(mortgage_total_balance)
label var mortgage_total_balance "Total Balance on Open Mortgage-Type Trades"

* Total Balance excluding mortgage
gen all_balance_excl_mta = all_total_balance - mortgage_total_balance
label var all_balance_excl_mta "Total Debt Without Mortgage"

*keeporder experian_id quarter $outcomes  sample 
tempfile outcomes
save `outcomes'

*******************************************************************************
* Merge Baseline characteristics and Experian Data
*******************************************************************************
use `bline_survey'
merge 1:m experian_id using `outcomes', keep(3)
gen qtrs_since_bline = qofd(date(quarter, "YM")) - qofd(date(baselinedate, "MDY"))
label var qtrs_since_bline "Number of Quarters to Randomization"
gen month_bline = mofd(date(baselinedate, "MDY"))
label var month_bline "Month R was randomized"




*******************************************************************************
* coefficient plot 
*******************************************************************************
cd "$Figures"

preserve
gen insample = !missing(credit_score) & inrange(qtrs_since_bline,3,5)
bysort experian_id: ereplace insample = max(insample)
keep if insample == 1

keep if inrange(qtrs_since_bline,-12,4)
foreach var in credit_score {
gen lag = `var' if qtrs_since_bline == -1
ereplace lag = max(lag), by(experian_id)

local counter = 1
local counter1 = -12
local coefplot
local label
forvalues i = -12/4  {
	qui reghdfe `var' treat_status lag $controls if qtrs_since_bline == `i',  absorb($fe) 
	count if e(sample)
	
	est store quart_`counter'
	local coefplot `coefplot' quart_`counter' ||
	local label `label' `counter1'
	local ++counter
	local ++counter1
}

coefplot `coefplot', vertical keep(treat_status) bycoefs yline(0) ///
                        xtitle("Quarters Since Enrollment") ///
			bylabels(`label') 
graph export "full_coef_`var'.png", replace
eststo clear
drop lag
}	
restore



*******************************************************************************
* Tables
*******************************************************************************

* Set up variables for tables
gen x     = .
gen const = 1
gen total = .

* Generate baseline variables

foreach var in $outcomes {
qui gen bline_`var' = `var' if qtrs_since_bline == -1
qui bysort experian_id: ereplace bline_`var' = max(bline_`var')
}

* Generate outcomes that use quarters 3-5. This change in made to be consistent with UI results

foreach var in $outcomes_continuous {
qui bysort experian_id (qtrs_since_bline): egen post_`var' = mean(`var') if inrange(qtrs_since_bline, 3, 5)
qui replace `var' = post_`var'
}

foreach var in $outcomes_binary {
qui bysort experian_id (qtrs_since_bline): egen post_`var' = max(`var') if inrange(qtrs_since_bline, 3, 5)
qui replace `var' = post_`var'
}

keep if qtrs_since_bline == 4	

* Outcome Table for 4 quarters

	eststo clear 	
	qui reg married_clean const
	eststo _filler
	
	esttab _filler _filler _filler _filler _filler ///
	using "ADM - Experian.tex", replace ///
	keep(const) drop(const) nogaps nonotes noobs b(a2) frag ///
	mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff.") 
	

	foreach var in  $outcomes  {

	eststo clear 	
	replace x = const

	qui mdesc `var'
	replace total = r(total)-r(miss)
	eststo _b0: qui reg total x , nocons  // number of observations
	eststo _b1: qui  reg `var' x, nocons r // full sample mean
	eststo _b2: qui  reg `var' x if treat_status == 1, nocons r // control mean
	eststo _b3: qui  reg `var' x if treat_status == 0, nocons r // treatment mean
	qui replace x = treat_status // adjusted difference
	eststo _b4: qui  reghdfe `var' x $controls , absorb($fe) vce(robust)
	
	if inlist("`var'", "all_balance_excl_mta", "mortgage_total_balance", "bankcard_total_balance", "all_total_balance" ,"credit_score") {
	esttab _b* using "ADM - Experian.tex", append ///
	keep(x) varlabels(x "`: var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%9.0fc)) b(pattern(0 1 1 1 0) fmt(%9.0fc)) b(pattern(1 0 0 0 0) fmt(%3.0f))" se(par fmt(%9.0fc) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nonum  noobs nogaps nomtitle nonotes nolines frag
	}
	else {
	esttab _b* using "ADM - Experian.tex", append ///
	keep(x) varlabels(x "`: var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%4.2f)) b(pattern(0 1 1 1 0) fmt(%4.2f)) b(pattern(1 0 0 0 0) fmt(%3.0f))" se(par fmt(%4.2f) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nonum  noobs nogaps nomtitle nonotes nolines frag
	}
	}

keep if !missing( has_debt)
keep experian_id
destring experian_id, replace
duplicates drop experian_id, force
save "${tim}/samples/Experian.dta", replace

