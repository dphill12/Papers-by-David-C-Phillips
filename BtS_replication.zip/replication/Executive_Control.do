*****************************************************************************
/*
Executive_control.do - Rochester Bridges to Success
	*Started: 5/25/17
	*Updated: 04/04/2023
	*Author: Tim Spilde
	*Purpose: cleans executive control data. Respondants are asked to complete an executive control test in followup survey. The first 20 questions are practice trials, the remaining 60 are real trials. 
	
	* In the test, either a green solid or red strip would appear. The figure would appear on the left or right side of the screen. If a Green Solid appeared, the correct action is to press "m" on a keyboard. If a red stripe apppeared, the correct action is to press "z" on the keyboard. 
	*Because m is on the right part of the keybaord, a congruent questions is when a Green Solid appeared on the right part of the screen. Analogously, a Red Strip appearing on the left part of the screen is also congruent.  
*/
******************************************************************************
* In the first section, I am dropping bad surveys and winzorizing data for all of the sections.

use  "$dta_loc/Clean Bline Final.dta", clear
cd "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim/Executive Control"
global fe randomization_group month_year months_btwn_surveys_cat
global controls female quarterly_r_earnings married_clean white black other hispanic ///
hs_GED_clean college_clean some_college_clean nohs_clean

keeporder Program experian_id $controls $fe  cog*_x *cogt*_time
destring *cogt*_time cogt*_x , replace
qui rename cogt*p_x pcogt*_x // makes loops easier

	drop if experian_id == 6497106 | experian_id == 6405471
* These people have all missing time scores
	drop if inlist(experian_id, 6497229, 6496737, 6607314, 6553686, 6459837, 6506823)

* Winzorize data
	forvalues i = 1/20 {
	qui sum pcogt`i'_time, detail
	replace pcogt`i'_time = r(p5)  if pcogt`i'_time < r(p5)
	replace pcogt`i'_time = r(p95) if pcogt`i'_time > r(p95)
	}
	forvalues i = 1/60 {
	qui sum cogt`i'_time, detail
	replace cogt`i'_time = r(p5)  if cogt`i'_time < r(p5)
	replace cogt`i'_time = r(p95) if cogt`i'_time > r(p95)
	}

save "Experian_data.dta", replace



use "$dta_loc/Clean Bline Final C2.dta", clear
keep if cohort == "2"


keeporder Program experian_id $controls $fe  cog*_x *cogt*_time
destring *cogt*_time cogt*_x , replace
qui rename cogt*p_x pcogt*_x // makes loops easier


	forvalues i = 1/20 {
	qui sum pcogt`i'_time, detail
	replace pcogt`i'_time = r(p5)  if pcogt`i'_time < r(p5)
	replace pcogt`i'_time = r(p95) if pcogt`i'_time > r(p95)
	}
	forvalues i = 1/60 {
	qui sum cogt`i'_time, detail
	replace cogt`i'_time = r(p5)  if cogt`i'_time < r(p5)
	replace cogt`i'_time = r(p95) if cogt`i'_time > r(p95)
	}

save "Experian_data_c2.dta", replace


use  "Experian_data.dta", clear
append using "Experian_data_c2.dta", force
save "Experian_data_all.dta", replace

******************************************************************************
* Make sure that trials were the same
*****************************************************************************
use  "$dta_loc/Clean Bline Final.dta", clear
forvalues i = 1(1)60 {
	egen true`i' = mode(cogt`i')
	
}
collapse (first) true*
gen cohort = "1"
tempfile test
save `test'
use "$dta_loc/Clean Bline Final C2.dta", clear
forvalues i = 1(1)60 {
	egen true`i' = mode(cogt`i')
	
}
collapse (first) true*
gen cohort = "2"
append using `test'

* The m's and z's all line up. This supports the idea that they are the same test
******************************************************************************
* Section 1 - Create lineplot of averave response time per question
*****************************************************************************
use  "Experian_data_all.dta", clear


cd "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim/Figures"
keep experian_id Program *cogt*_time


collapse (mean) *cogt*_time, by( Program)
rename (cogt*_time pcogt*_time) (cogtime_* pcogtime_*)
forvalues i = 60(-1)1 {
	rename cogtime_`i' cogtime_`=`i'+20'
}
rename pcogtime_* cogtime_*
reshape long cogtime_ , i(Program) j(trial)
drop if trial == 1
twoway (line cogtime_ trial if Program == "TREATMENT") (line cogtime_ trial if Program == "CONTROL", lpattern(dash)) , ///
ytitle("Mean Response Time (ms)") xtitle("Trial Number") legend(order(1 "Treatment" 2 "Control")  ring(0) position(2) bmargin(small) ) xline(20)

graph export "trials.png", replace

******************************************************************************
* Section 2 - Create statistics for Table
*****************************************************************************
cd "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim/Executive Control"
use  "Experian_data_all.dta", clear
cd "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim/Figures"

keeporder experian_id Program $controls $fe  cog*_x *cogt*_time


* This turns all cogt`i'_x variables into a binary that equals 1 if correct
forvalues i = 1/60 {
replace cogt`i'_x = 0 if missing(cogt`i'_x)
replace cogt`i'_x = (cogt`i'_x == 0)
}


* Get average push times and percent correct
egen cogt_time_avg = rmean(cogt*_time)
label var cogt_time_avg "Average Push Time (ms)"
egen cogt_rate = rmean(cogt*_x)
replace cogt_rate = cogt_rate*100
label var cogt_rate "Percent Correct"


gen x = 1
gen const = 1
gen total = .	
gen treat_status = (Program == "TREATMENT")

qui reg cogt59_x const
eststo _filler
esttab _filler _filler _filler _filler _filler ///
using "ADM - Executive Control.tex", replace ///
keep(const) drop(const) ///
mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Difference") ///
nogaps nonotes noobs b(a2) frag
replace treat_status = (Program == "TREATMENT")
*Fill in table	
foreach var in cogt_time_avg cogt_rate {
	eststo clear 	
	qui replace x = const
	
	qui mdesc `var'
	replace total = r(total)-r(miss)
	quietly reg total x , nocons
	eststo _b0
	quietly reg `var' x, nocons r 
	eststo _b1
	quietly reg `var' x if treat_status == 1, nocons r
	eststo _b2				
	quietly reg `var' x if treat_status == 0, nocons r
	eststo _b3				
	quietly replace x = treat_status
	reghdfe `var' x $controls , absorb($fe) vce(robust)
	eststo _b4

	esttab _b* using ///
	"ADM - Executive Control.tex", append ///
	keep(x) varlabels(x "`: var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%4.1f)) b(pattern(0 1 1 1 0) fmt(%4.1f)) b(pattern(1 0 0 0 0) fmt(%4.0f)) " se(par fmt(%4.1f) pattern(0 0 0 0 1)) ) ///
	starlevel(* 0.10 ** 0.05 *** 0.01)  ///
	collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag posthead(\textit{Trials}\\)
}
	

******************************************************************************
******************************************************************************
cd "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim/Executive Control"
use  "Experian_data_all.dta", clear
cd "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim/Figures"


keeporder experian_id Program $controls $fe  cog*_x *cogt*_time


* This turns all cogt`i'_x variables into a binary that equals 1 if correct
forvalues i = 1/60 {
replace cogt`i'_x = 0 if missing(cogt`i'_x)
replace cogt`i'_x = (cogt`i'_x == 0)
}


* This section looks at if the question was congruent. For example, if they were to click "z", was the symbol on the right or the left?
matrix m =     (1\0\0\1\0\1\1\1\1\0\1\0\1\1\1\0\0\1\0\0\ ///
				1\0\0\1\1\1\1\0\1\1\0\0\0\1\0\1\0\1\0\0\ ///
				0\1\0\0\1\0\1\1\0\1\1\0\0\0\1\1\1\0\0\0)


foreach var in x time {
global same_`var'
global opp_`var'

forvalues i = 1/60 {
if  m[`i',1] == 1 {
global same_`var' ${same_`var'} cogt`i'_`var'

}
else if m[`i',1] == 0 {
global opp_`var' ${opp_`var'}  cogt`i'_`var'
}
}
}

foreach var in same opp {
egen cogt_rate_`var' = rmean(${`var'_x})
replace cogt_rate_`var' = cogt_rate_`var' * 100
egen cogt_time_avg_`var' = rmean(${`var'_time})
}

label var cogt_rate_same "Percent Correct"
label var cogt_time_avg_same "Average Push Time"
label var cogt_rate_opp "Percent Correct"
label var cogt_time_avg_opp "Average Push Time"

gen x = 1
gen const = 1
gen total = .	




gen treat_status = (Program == "TREATMENT")
*Fill in table	
foreach var in cogt_time_avg_same cogt_rate_same cogt_time_avg_opp cogt_rate_opp {
	eststo clear 	
	qui replace x = const
	
	qui mdesc `var'
	replace total = r(total)-r(miss)
	quietly reg total x , nocons
	eststo _b0
	quietly reg `var' x, nocons r 
	eststo _b1
	quietly reg `var' x if treat_status == 1, nocons r
	eststo _b2				
	quietly reg `var' x if treat_status == 0, nocons r
	eststo _b3				
	quietly replace x = treat_status
	reghdfe `var' x $controls , absorb($fe) vce(robust)
	eststo _b4

	esttab _b* using ///
	"ADM - Executive Control.tex", append ///
	keep(x) varlabels(x "`: var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%4.1f)) b(pattern(0 1 1 1 0) fmt(%4.1f)) b(pattern(1 0 0 0 0) fmt(%4.0f)) " se(par fmt(%4.1f) pattern(0 0 0 0 1)) ) ///
	starlevel(* 0.10 ** 0.05 *** 0.01)  ///
	collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag posthead(\textit{Trials}\\)
}

/* 

Practice Trials
congruent trials
4 5
6 7
11 13
17 19 20

incongruent trials
1 2 3
8 9 10
12 14 15
16 18
*/




/*  Real Trials
congruent trials
1 4 
6 7 8 9
11 13 14 15
18
21 24 25
26 27 29 30
34
36 38
42 45
47 48 50
51 55
56 57

incongruent trials
2 3 5
10
12	
16 17 19 20
22 23
28
31 32 33 35
37 39 40
41 43 44
46 49
52 53 54
58 59 60 */
