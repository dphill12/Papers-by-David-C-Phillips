Replication code for: "How Do Holistic Wrap-Around Anti-Poverty Programs
Affects Employment and Individualized Outcomes."

The authors created this replication code for any readers with particular
interest in the details of the analysis. This package was created
after the paper was published. 

This folder includes the Master.do file for all data cleaning and analysis.
We also include some do files that are called at the end of the master do
that create the tables in the paper. Data are not included as many data sources 
have limitations on data sharing from the owners of the data. The included pdf 
shows the tables that are created by this code. Very minor differences between
this pdf and the published version result from (i) a small change to the set of
control variables that was made during the review process which is reflected
in the main tables in the published version but not many appendix tables that
we have now updated and (ii) setting random number seeds. 

