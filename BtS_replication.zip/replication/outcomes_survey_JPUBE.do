set seed 880004	
scalar reps = 1000

global dta_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/DTA Files"

use "$dta_loc/Clean Bline Final.dta", clear
gen cohort = 1
append using "$dta_loc/Clean Bline Final C2.dta", force
replace cohort = 2 if missing(cohort)

replace treat_status = treatment_final if missing(treat_status)
cd $Figures


global controls female quarterly_r_earnings married_clean white black other hispanic ///
bline_nohs_clean bline_hs_ged_clean bline_some_college_clean bline_college_clean 
global fe cohortXmonth_year randomization_group months_btwn_surveys_cat
qui gen x = .
qui gen const = 1
qui gen total = .
qui gen interact = .
qui gen p_diff = .
gen z = .
eststo clear

gen cohortXmonth_year = month_year * 10 + cohort
gen bline_missing = .

/*

**********************************************************************
*  Table 2 - Services received
**********************************************************************	

rename edu_at_y1_clean ed_at_y1_clean


global other_services bscp_y1_clean bscp  oth_sim_prog ///
 related_goal related_primary_goal hous_at_y1_clean fam_at_y1_clean phys_at_y1_clean mentl_at_y1_clean ///
ed_at_y1_clean emp_at_y1_clean fin_at_y1_clean


gen oth_sim_prog = fii_y1_clean
replace oth_sim_prog = 1 if swfi_y1_clean == 1
replace oth_sim_prog = 1 if hpog_y1_clean == 1
replace oth_sim_prog = 1 if pwsa_y1_clean == 1
label var oth_sim_prog "Any Other Similar Org."


gen bscp = inlist(org_freq_bscp,1,2,3,4)
replace bscp = . if org_invbscp == -8


gen related_goal = 0
gen related_primary_goal = 0
foreach var in goal primary_goal {
replace related_`var' = 1 if hous_at_y1_clean == 1 & `var'_housing_clean== 1
replace related_`var' = 1 if fam_at_y1_clean == 1 & `var'_family_clean == 1
replace related_`var' = 1 if phys_at_y1_clean == 1 & `var'_health_clean == 1
replace related_`var' = 1 if mentl_at_y1_clean == 1 & `var'_health_clean == 1
replace related_`var' = 1 if ed_at_y1_clean == 1 & `var'_edu_clean == 1 == 1
replace related_`var' = 1 if emp_at_y1_clean == 1 & `var'_employment_clean == 1 == 1
replace related_`var' = 1 if fin_at_y1_clean== 1 & `var'_finances_clean == 1 == 1
}
replace related_primary_goal = . if missing(primarygoal)
label var bscp "Involved Once per Month"
label var bscp_y1_clean "Any Involvement"
label var fii_y1_clean "Family Independence Initiative"
label var swfi_y1_clean "Strengthening Working Families Initiative"
label var hpog_y1_clean "Health Profession Opportunity Grants"
label var related_goal  "-Any Org."
label var related_primary_goal "-Any Org. in Primary Goal"
label var pwsa_y1_clean "Pathway of Hope"
label var hous_at_y1_clean "-Housing"
label var fam_at_y1_clean "-Family"
label var phys_at_y1_clean "-Physical Health"
label var mentl_at_y1_clean "-Mental Health"
label var ed_at_y1_clean "-Education"
label var emp_at_y1_clean "-Employment"
label var fin_at_y1_clean   "-Financial"

		
 		eststo clear 	
		qui reg earnings_increase const
		eststo _filler
	 
		esttab _filler _filler _filler _filler _filler ///
		using "ADM - Services RI.tex", replace ///
		keep(const) drop(const) ///
		mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-value") ///
		nogaps nonotes noobs b(a2) frag
		
		*Fill in table	
		foreach var in $other_services {
			local head
			if "`var'" == "bscp_y1_clean" {
			local head prehead("\textbf{Bridges to Success} \\")	
			}
			if "`var'" == "oth_sim_prog" {
			local head prehead("\textbf{Similar Org.} \\")	
			}
			if "`var'" == "related_goal" {
			local head prehead("\textbf{Any Outside Org. Related to} \\")	 
			}			
			
			
			eststo clear 	
			qui replace x = const
			qui mdesc `var'
			replace total = r(total)-r(miss)
			eststo _b0: quietly reg total x , nocons
			eststo _b1: qui reg `var' x, nocons r 
			eststo _b2: qui reg `var' x if treat_status == 1, nocons r		
			eststo _b3: qui reg `var' x if treat_status == 0, nocons r				
			quietly replace x = treat_status
			*eststo _b4:  logit `var' x $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
			qui logit `var' x $controls i.cohortXmonth_year i.months_btwn_surveys_cat  , vce(robust)
			*logit `var' x $controls cohort i.months_btwn_surveys_cat  , vce(robust)			
			eststo _b4: qui margins, dydx(x) post
			scalar beta  = e(b)[1,1]
			scalar se    = sqrt(e(V)[1,1])
			replace z     = beta/se
			replace  p_diff  = 2*(1-normal(abs(z)))
			display "Coef = " beta "  SE = " se "  p = " p_diff	

			*ritest treat_status (_b[treat_status]),  strata(randomization_group)  reps(`=reps'): logit `var' treat_status $controls i.cohortXmonth_year i.months_btwn_surveys_cat , vce(robust)	
			qui ritest treat_status (_b[treat_status]),  strata(randomization_group)  reps(`=reps'): logit `var' treat_status $controls cohort , vce(robust)				
			
			* Get New P Vallue
			qui replace  p_diff = r(p)[1,1]
			qui replace x = const
			eststo _b5:  reg p_diff x, nocons		

			esttab _b* using ///
			"ADM - Services RI.tex", append ///
			keep(x) varlabels(x "`: var label `var''") se ///
			cells("b(star pattern(0 0 0 0 1 0) fmt(%3.2f)) b(pattern(0 1 1 1 0) fmt(%3.2f)) b(pattern(1 0 0 0 0 0) fmt(%3.0f))" se(par fmt(%3.2f) pattern(0 0 0 0 1 0))) ///
			starlevel(* 0.10 ** 0.05 *** 0.01) `head' ///
			collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
		}

		
		
 







**********************************************************************
* Table 4 Outcomes in Many Domains, Full Sample
**********************************************************************	
 * Bridge Outcomes
global main_outcomes earnings_increase home_quality_ctrl_med_y1 progress_self progress_bridge
global bridge_components1 pos_child_outcome health_increase social_index_increase ///
			pos_ed_outcome net_asset_increase 


foreach var in $controls {
	di "`var'"
	count if missing(`var')
}

label var earnings_increase "Quarterly Earnings Increase"
label var home_quality_ctrl_med_y1 "High Home Quality"
label var progress_self "Improvement in Primary Goal "
label var progress_bridge "Improvement in Primary Goal (Bridge Tool)"
label var pos_child_outcome "All Children Enrolled in School"
label var health_increase "Increased Health"
label var social_index_increase "Increased Social Networks "
label var pos_ed_outcome "Increased Education or Enrolled"
label var net_asset_increase "Increased Net Assets"



		eststo _filler: qui reg earnings_increase const
		esttab _filler _filler _filler _filler _filler _filler using ///
		"ADM - Main Outcomes RI.tex", replace ///
		keep(const) drop(const) ///
		nogaps nonotes noobs  nolines b(a2) frag ///
		mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-value")
				
	*Loop through and fill in table 
			foreach var in $main_outcomes $bridge_components1 {
			eststo clear	
			quietly replace x = const
			di "`var'"
			qui mdesc `var'
			replace total = r(total)-r(miss)
			eststo _b0: qui reg total x , nocons
			eststo _b1: qui reg `var' x, nocons r
			eststo _b2: qui reg `var' x if treat_status == 1, nocons r					
			eststo _b3: qui reg `var' x if treat_status == 0, nocons r			
			quietly replace x = treat_status
			qui logit `var' x $controls i.cohortXmonth_year i.months_btwn_surveys_cat,  vce(robust)
			eststo _b4: qui margins, dydx(x) post			
			* Keep TE and SE
			qui ritest treat_status (_b[treat_status]),  strata(randomization_group)  reps(`=reps'): reghdfe `var' treat_status $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
			* Get New P Vallue
			qui replace  p_diff = r(p)[1,1]
			qui replace x = const
			eststo _b5:  reg p_diff x, nocons

			
			esttab _b* using "ADM - Main Outcomes RI.tex", append ///
			keep(x) varlabels(x "`: var label `var''") se ///
			cells("b(star pattern(0 0 0 0 1 0) fmt(%3.2f)) b(pattern(0 1 1 1 0) fmt(%3.2f)) b(pattern(1 0 0 0 0 0) fmt(%3.0f))" se(par fmt(%3.2f) pattern(0 0 0 0 1 0))) ///
			starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nodepvars nonum nomtitle nogaps nonotes nolines frag noobs 
		}	
		*/
**********************************************************************
* Table A.13 - Detailed Employment
**********************************************************************



global employment working hours_perwk hourly_wage1 hourly_wage2 hh_inc_lastyear
label var working_y1_clean "Employed"
label var hours_perwk_y1_clean "Hours Worked per Week"
label var hourly_wage1_y1_clean "Hourly Wage (Simple, Employed)"
label var hourly_wage2_y1_clean "Hourly Wage (Dynamic, Employed)"
label var hh_inc_lastyear_y1_clean "Total Household Income"


replace hourly_wage1_y1_clean = . if hourly_wage1_y1_clean == 0
replace hourly_wage2_y1_clean = . if hourly_wage2_y1_clean == 0

rename (hours_worked_uweek_clean hh_income_lastyear_clean) (hours_perwk_clean hh_inc_lastyear_clean)

eststo clear 	
qui reg working_y1_clean const
eststo _filler

esttab _filler _filler _filler _filler _filler _filler ///
using "ADM - Employment.tex", replace ///
keep(const) drop(const) ///
mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-value") ///
nogaps nonotes noobs b(a2) frag

*Fill in table	
foreach var in $employment {
	eststo clear	
	quietly replace x = const
	qui mdesc `var'_y1_clean
	qui replace total = r(total)-r(miss)
	display "hi"
	eststo _b0: quietly reg total x , nocons
		display "hi"
	eststo _b1: quietly reg `var'_y1_clean x, nocons r 
		display "hi"
	eststo _b2: quietly reg `var'_y1_clean x if  treat_status == 1, nocons r			
		display "hi"
	eststo _b3: quietly reg `var'_y1_clean x if  treat_status == 0, nocons r	
		display "hi"
	qui replace x =  treat_status

	if "`var'" == "working_y1_clean" {
		logit `var'_y1_clean x `var'_clean $controls i.cohortXmonth_year  i.months_btwn_surveys_cat, robust
		eststo _b4: margins, dydx(x) post
		scalar beta  = e(b)[1,1]
		scalar se    = sqrt(e(V)[1,1])
		replace z     = beta/se
		replace  p_diff  = 2*(1-normal(abs(z)))
		display "Coef = " beta "  SE = " se "  p = " p_diff	
		ritest treat_status (_b[treat_status]),  strata(randomization_group)  reps(1000): logit `var'_y1_clean treat_status `var'_clean  $controls i.cohortXmonth_year i.months_btwn_surveys_cat , vce(robust)	
		qui replace  p_diff = r(p)[1,1]
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons		
	}
	
	else {
		eststo _b4: qui reghdfe `var'_y1_clean x `var'_clean $controls , absorb(cohortXmonth_year months_btwn_surveys_cat) vce(robust)
		ritest treat_status (_b[treat_status]),  strata(randomization_group)  reps(1000): reghdfe `var'_y1_clean treat_status `var'_clean $controls , vce(robust)  absorb(cohortXmonth_year months_btwn_surveys_cat)
		qui replace  p_diff = r(p)[1,1]
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons		
	}
			
	if "`var'" == "hh_inc_lastyear" {
		local dig = 0
	}
	if "`var'" != "hh_inc_lastyear" {
		local dig = 2
	}

	esttab _b* using "ADM - Employment.tex", append ///
		keep(x) varlabels(x "`: var label `var'_y1_clean'") se ///
		cells("b(star pattern(0 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 1 1 1 0) fmt(%3.2f)) b(pattern(1 0 0 0 0 0) fmt(%3.0f))" se(par fmt(%9.`dig'fc) pattern(0 0 0 0 1 0))) ///
		starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nodepvars nonum nomtitle nogaps nonotes nolines frag noobs 

}	

**********************************************************************
* Table A.14 Outcomes in Many Domains, Narrow Sample
**********************************************************************	
		***** For people with not missing self progress measure
		preserve
		keep if !missing(progress_self)
		eststo _filler: qui reg earnings_increase const
		esttab _filler _filler _filler _filler _filler _filler using ///
		"ADM - Main Outcomes Subgroup RI.tex", replace ///
		keep(const) drop(const) ///
		nogaps nonotes noobs  nolines b(a2) frag ///
		mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-value")
				
	*Loop through and fill in table 
			foreach var in $main_outcomes $bridge_components1 {
			eststo clear	
			quietly replace x = const
			di "`var'"

			eststo _b1: qui reg `var' x, nocons r
			eststo _b2: qui reg `var' x if treat_status == 1, nocons r					
			eststo _b3: qui reg `var' x if treat_status == 0, nocons r			
			quietly replace x = treat_status
			qui logit `var' x $controls i.cohortXmonth_year i.months_btwn_surveys_cat,  vce(robust)
			ereplace total = total(e(sample))
			sum total
			eststo _b4: qui margins, dydx(x) post			
			* Keep TE and SE
			
			replace x = const
			
			eststo _ss: reg total x, nocons
			
			qui ritest treat_status (_b[treat_status]),  strata(randomization_group)  reps(`=reps'): reghdfe `var' treat_status $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
			* Get New P Vallue
			qui replace  p_diff = r(p)[1,1]
			qui replace x = const
			eststo _b5: qui reg p_diff x, nocons

			
			esttab _ss _b* using "ADM - Main Outcomes Subgroup RI.tex", append ///
			keep(x) varlabels(x "`: var label `var''") se ///
			cells("b(star pattern(0 0 0 0 1 0) fmt(%3.2f)) b(pattern(0 1 1 1 0) fmt(%3.2f)) b(pattern(1 0 0 0 0 0) fmt(%3.0f))" se(par fmt(%3.2f) pattern(0 0 0 0 1 0))) ///
			starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nodepvars nonum nomtitle nogaps nonotes nolines frag noobs 
		}	

		restore
		
		
		
		
**********************************************************************
* Table A.15 Contiuous Outcomes
**********************************************************************	
global main_continuous 	quarterly_r_earnings home_quality lastyr_goal primary_con per_kids_school health networks_index net_assets 
global main_continuous_y1 quarterly_r_earnings_y1 home_quality_y1 per_kids_school_y1 health_y1 networks_index_y1 net_assets_y1
gen home_quality = 0 // no baseline value
gen lastyr_goal = 0 // no baseline value
gen per_kids_school = num_kids_inschool_clean/num_kids
gen per_kids_school_y1 = num_kids_inschool_y1_clean/num_kids_y1


label var quarterly_r_earnings_y1  "Quarterly Earnings (\\\$)"
label var home_quality_y1 "Home Quality (Likert)"
label var per_kids_school_y1 "\% Children in Enrolled School"
label var health_y1 "Health Status (Likert)"
label var networks_index_y1 "Social Networks Index (Sum of Z-Scores)"
label var net_assets_y1 "Net Assets (\\\$)"
label var lastyr_goal_y1 "Primary Goal (Likert)"




label var oth_sim_prog "Any Other Similar Org."

foreach var in $main_continuous_y1 {
	egen z_`var' = std(`var')
}
foreach var in $main_continuous {
	if "`var'" ~= "primary_con" & "`var'" ~= "lastyr_goal" {
		egen z_`var' = std(`var')
	}
}

gen primary_con_y1 = .
replace primary_con_y1 = z_quarterly_r_earnings_y1 if primary_goal_employment_clean == 1
replace primary_con_y1 = z_home_quality_y1 if primary_goal_housing_clean == 1
replace primary_con_y1 = z_per_kids_school_y1 if primary_goal_family_clean == 1
replace primary_con_y1 = z_health_y1 if primary_goal_health_clean == 1
replace primary_con_y1 = z_networks_index_y1 if primary_goal_networks_clean == 1
replace primary_con_y1 = z_net_assets_y1 if primary_goal_finances_clean == 1
gen primary_con = 0

label var primary_con_y1 "Primary Goal - Bridge Tool (Z-Score)"

	
		qui reg earnings_increase const
		eststo _filler
		esttab _filler _filler _filler _filler _filler _filler using ///
		"ADM - Main Outcomes continuous.tex", replace ///
		keep(const) drop(const) ///
		nogaps nonotes noobs  nolines b(a2) frag ///
		mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value")
				
	*Loop through and fill in table  
			foreach var in $main_continuous {
				
				
				
				
			eststo clear	
			quietly replace x = const
local dig = 2
			qui mdesc `var'
			qui replace total = r(total)-r(miss)
			eststo _b0: qui reg total x , nocons
			eststo _b1: qui reg `var'_y1 x, nocons r 
			eststo _b2: qui reg `var'_y1 x if treat_status == 1, nocons r					
			eststo _b3: qui reg `var'_y1 x if treat_status == 0, nocons r			
			quietly replace x = treat_status
			eststo _b4: reghdfe `var'_y1 x $controls `var' i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
			
			 ritest treat_status (_b[treat_status]),  strata(randomization_group)  reps(`=reps'): reghdfe `var'_y1 treat_status $controls `var' i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
			qui replace  p_diff = r(p)[1,1]
			qui replace x = const
			eststo _b5:  reg p_diff x, nocons
			
			esttab _b* using "ADM - Main Outcomes continuous.tex", append ///
	keep(x) varlabels(x "`:var label `var'_y1'") se ///
	cells("b(star pattern(0 0 0 0 1 0) fmt(%4.2fc)) b(pattern(0 1 1 1 0 0) fmt(%4.2fc)) b(pattern(1 0 0 0 0 0) fmt(%4.0f)) b(pattern(0 0 0 0 0 1)  fmt(%4.2f))" se(par fmt(%4.2f) pattern(0 0 0 0 1 0))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nodepvars nonum nomtitle nogaps nonotes nolines frag noobs
		}
		
**********************************************************************
* Table A.16 Benefits
**********************************************************************			
	*this needs to be combined with the output from "tim/snap.do" for 
	* the government records


rename ui_wc_amt ui_wcamt

rename (credit_card_debt_clean credit_card_debt_amt_clean) (cc_debt_clean cc_debt_amt_clean)
rename budg_clean budget_clean


global finance acct acct_amt hh_inc_lastyear    ///
food_pantry  claimed_eitc payday payday_multiple rollover ///
liabilities cc_debt cc_debt_amt budget

global benefits snap_amt tanf_amt ssi_amt ssa_amt  wic_amt ui_wcamt childsup_amt ff_gifts

foreach var in snap_amt_y1 tanf_amt_y1 ssa_amt_y1 ssi_amt_y1 childsup_amt_y1 ui_wcamt_y1 ff_gifts_y1 wic_y1 wic_amt_y1 snap_amt tanf_amt ssa_amt ssi_amt childsup_amt ui_wcamt wic_amt food_pantry_y1 claimed_eitc_y1 liabilities liabilities_y1 {
	qui replace `var' = 0 if `var' < 0
	rename `var'  `var'_clean
}





label var acct_y1_clean "Any Bank Account"
label var acct_amt_y1_clean "Amount in Bank Account"
label var hh_inc_lastyear_y1_clean "HH Income (\\\$)"
label var childsup_amt_y1_clean "Child Support (\\\$)"
label var ff_gifts_y1_clean "Gifts (\\\$)"
label var food_pantry_y1_clean "Any Food Pantry"
label var claimed_eitc_y1_clean "Claimed EITC"
label var payday  "Any Dayday Loan"
label var payday_multiple_y1_clean  "Multiple Payday Loans"
label var rollover_y1_clean "Any Rollover from a Payday Loan"
label var liabilities_y1_clean "Liabilities (\\\$)"
label var cc_debt_y1_clean "Any HH Credit Card Debt"
label var cc_debt_amt_y1_clean "HH Credit Card Debt (\\\$)"
label var budget_y1_clean "Any HH Budget"

eststo clear 	
eststo _filler: qui reg earnings_increase const


esttab _filler _filler _filler _filler _filler ///
using "ADM - Benefits Survey.tex", replace ///
keep(const) drop(const) ///
mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff.") ///
nogaps nonotes noobs b(a2) frag posthead(\hline \textbf{Survey} \\ ) ///

*Fill in table	
foreach var in $benefits {
	eststo clear 	
	qui replace x = const
	local head 
	replace bline_missing = missing(`var'_clean)
	qui sum `var'_clean, d
	replace `var'_clean = `r(mean)' if missing(`var'_clean)	
	 mdesc `var'_y1_clean
	 
	replace total = r(total)-r(miss)
	eststo _b0: qui reg total x , nocons
	eststo _b1: qui reg `var'_y1_clean x, nocons r 
	eststo _b2: qui reg `var'_y1_clean x if treat_status == 1, nocons r
	eststo _b3: qui reg `var'_y1_clean x if treat_status == 0, nocons r			
	quietly replace x = treat_status
	eststo _b4: qui reghdfe `var'_y1_clean x `var'_clean $controls bline_missing, absorb($fe) vce(robust)

	local dig = 0
	if "`var'" == "snap_amt"{
	local head prehead("Amount (\\\$) HH Received Last Month From:\\")	
	} 
	esttab _b* using "ADM - Benefits Survey.tex", append ///
	keep(x) varlabels(x "`: var label `var'_y1_clean'") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%9.`dig'fc)) b(pattern(0 1 1 1 0) fmt(%9.`dig'fc)) b(pattern(1 0 0 0 0) fmt(%4.0f)) " se(par fmt(%4.`dig'f) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag `head'
}

**********************************************************************
* Table A.17 - Housing
**********************************************************************
* Incoperate last move date and infutor

rename (home_quality_y1 neigh_crime_y1 sch_quality_y1 neigh_quality_y1) (home_quality_y1_clean neigh_crime_y1_clean sch_quality_y1_clean neigh_quality_y1_clean)

* Not in baseline survey
gen home_quality_clean = 1
gen neigh_crime_clean = 1
gen sch_quality_clean = 1
gen neigh_quality_clean = 1
gen windows_clean = 1
gen leak_clean = 1
gen heating_clean = 1
gen legal_eviction_clean = 1

global housing own_rent windows leak heating ///
home_quality neigh_crime sch_quality neigh_quality legal_eviction evict ///
num_hh num_kids num_seniors num_nonworking

label var own_rent_y1_clean "Owns or Pays Rent"
label var windows_y1_clean "Broken or Boarded Windows"
label var leak_y1_clean "Leak in Home"
label var heating_y1_clean "Heating Issue"
label var home_quality_y1 "Home Quality"
label var neigh_crime_y1 "Crime Severity"
label var sch_quality_y1 "School Quality"
label var neigh_quality_y1 "Neighborhood Quality"
label var legal_eviction_y1 "Involved in Eviction or Foreclosure"
label var evict_y1_clean "Evicted Past Year"
label var num_hh_y1_clean "Number of People in HH"
label var num_kids_y1_clean"Number of Kids in HH"
label var num_seniors_y1_clean "Number of Seniors in HH"
label var num_nonworking_y1_clean "Number of Nonworking Adults in HH"


eststo clear 	
eststo _filler: qui reg earnings_increase const

esttab _filler _filler _filler _filler _filler ///
using "ADM - Housing.tex", replace ///
keep(const) drop(const) ///
mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff.") ///
nogaps nonotes noobs b(a2) frag

*Fill in table	
foreach var in $housing {
	
	replace bline_missing = missing(`var'_clean)
	qui sum `var'_clean, d
	replace `var'_clean = `r(mean)' if missing(`var'_clean)
	
	eststo clear 	
	qui replace x = const
	
	 mdesc `var'_y1_clean
	replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons
	eststo _b1: quietly reg `var'_y1_clean x, nocons r 
	eststo _b2: quietly reg `var'_y1_clean x if treat_status == 1, nocons r
	eststo _b3:  reg `var'_y1_clean x if treat_status == 0, nocons r			
	quietly replace x = treat_status
	eststo _b4: qui reghdfe `var'_y1_clean x `var'_clean $controls bline_missing, absorb($fe) vce(robust)

	esttab _b* using "ADM - Housing.tex", append ///
	keep(x) varlabels(x "`: var label `var'_y1_clean'") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%4.2f)) b(pattern(0 1 1 1 0) fmt(%4.2f)) b(pattern(1 0 0 0 0) fmt(%4.0f)) " se(par fmt(%4.2f) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01)  collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
} 	

**********************************************************************
* Table A.18 Family
**********************************************************************
global family kids_nowork kids_misswork avg_times_absent depend_care goal_fam legal_marital family_index

eststo clear 	
qui reg earnings_increase const
eststo _filler

esttab _filler _filler _filler _filler _filler ///
using "ADM - Family.tex", replace ///
keep(const) drop(const) ///
mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff.") ///
nogaps nonotes noobs b(a2) frag

*Fill in table	
foreach var in $family {
	eststo clear 	
	qui replace x = const
	

	qui mdesc `var'_y1
	replace total = r(total)-r(miss)
	eststo _b0:  qui reg total x , nocons
	eststo _b1:  qui reg `var'_y1 x, nocons r 
	eststo _b2: quietly reg `var'_y1 x if treat_status == 1, nocons r
	eststo _b3:  qui reg `var'_y1 x if treat_status == 0, nocons r			
	quietly replace x = treat_status
	eststo _b4:  qui reghdfe `var'_y1 x `var' $controls , absorb($fe) vce(robust)

	esttab _b* using "ADM - Family.tex", append ///
	keep(x) varlabels(x "`: var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%4.2f)) b(pattern(0 1 1 1 0) fmt(%4.2f)) b(pattern(1 0 0 0 0) fmt(%4.0f)) " se(par fmt(%4.2f) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01)  ///
	collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
}

**********************************************************************
* Table A.19 Health
**********************************************************************


rename (dentist6mos_clean doctor6mos_clean) (den6mos_clean doc6mos_clean)

global health chronic er_visit num_doc_visits ///
health_goto doc6mos den6mos treatment_delay

label var chronic_y1_clean "Any Chronic Health Condition"
label var er_visit_y1_clean "Any ER Vist (Year)"
label var num_doc_visits_y1_clean "Number Doctor Visits (Year)"
label var health_goto_y1_clean "Has go-to Doctor"
label var doc6mos_y1_clean "Any Doctor visits (6 Months)"
label var den6mos_y1_clean "Any Dentists Visits (6 Months)" 
label var treatment_delay_y1_clean "Any Delayed Medical Treatment"

eststo clear 	
qui reg earnings_increase const
eststo _filler

esttab _filler _filler _filler _filler _filler ///
using "ADM - Health.tex", replace ///
keep(const) drop(const) ///
mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff.") ///
nogaps nonotes noobs b(a2) frag

*Fill in table	
foreach var in $health {

	replace bline_missing = missing(`var'_clean)
	qui sum `var'_clean, d
	replace `var'_clean = `r(mean)' if missing(`var'_clean)
	
	eststo clear 	
	qui replace x = const
	
	quietly mdesc `var'_y1_clean
	replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons
	eststo _b1: quietly reg `var'_y1_clean x, nocons r 
	eststo _b2: quietly reg `var'_y1_clean x if treat_status == 1, nocons r
	eststo _b3: qui reg `var'_y1_clean x if treat_status == 0, nocons r			
	quietly replace x = treat_status
	eststo _b4: qui reghdfe `var'_y1_clean x `var'_clean $controls bline_missing, absorb($fe) vce(robust)

	esttab _b* using "ADM - Health.tex", append ///
	keep(x) varlabels(x "`: var label `var'_y1_clean'") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%4.2f)) b(pattern(0 1 1 1 0) fmt(%4.2f)) b(pattern(1 0 0 0 0) fmt(%4.0f)) " se(par fmt(%4.2f) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01)  ///
	collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
}

**********************************************************************
* Table A.20 Networks
**********************************************************************
global networks_z orgs_num borrow_num closefri_num closerel_num relig neigh_num relig_num networks_index

replace relig_num = relig_num_clean
replace relig_num = 0 if missing(relig_num)
replace relig_num_y1 = relig_num_y1_clean

replace relig = relig_clean

label var orgs_num_y1 "Organizations Involved in"
label var borrow_num_y1 "People to Borrow From"
label var closefri_num_y1 "Close Friends"
label var closerel_num_y1 "Close Relatives"
label var relig_y1 "Any Religious Group"
label var neigh_num_y1 "Interactions with Neighbors"
label var relig_num_y1 "Religious Group Interactions"
label var networks_index_y1 "Z Score Index"
 
eststo clear 	
qui reg earnings_increase const
eststo _filler

esttab _filler _filler _filler _filler _filler ///
using "ADM - Netowrks.tex", replace ///
keep(const) drop(const) ///
mtitles("Sample Size" "Full Sample" "Control" "Treatment" "Adj. Diff.") ///
nogaps nonotes noobs b(a2) frag

*Fill in table	
foreach var in $networks_z {
	
	
	replace bline_missing = missing(`var')
	qui sum `var', d
	replace `var' = `r(mean)' if missing(`var')
	
	eststo clear 	
	qui replace x = const
	
	 mdesc `var'_y1
	replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons
	eststo _b1: quietly reg `var'_y1 x, nocons r 
	eststo _b2: quietly reg `var'_y1 x if treat_status == 1, nocons r
	eststo _b3:  reg `var'_y1 x if treat_status == 0, nocons r			
	quietly replace x = treat_status
	eststo _b4: qui reghdfe `var'_y1 x `var' $controls bline_missing, absorb($fe) vce(robust)

	esttab _b* using "ADM - Netowrks.tex", append ///
	keep(x) varlabels(x "`: var label `var'_y1'") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%4.2f)) b(pattern(0 1 1 1 0) fmt(%4.2f)) b(pattern(1 0 0 0 0) fmt(%4.0f))" se(par fmt(%4.2f) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01)  ///
	collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
}



**********************************************************************
* Table A.21 Education
**********************************************************************
global education inhighschool incollege invoc ///
hs_GED coll_deg cert_license educ_increase pos_ed_outcome


rename (in_highschool_clean in_college_clean in_vocational_clean college_clean) (inhighschool_clean incollege_clean invoc_clean coll_deg_clean) 
rename (educ_increase pos_ed_outcome) (educ_increase_y1_clean pos_ed_outcome_y1_clean)
label var inhighschool_y1_clean "In Highschool"
label var incollege_y1_clean "In College"
label var invoc_y1_clean "In Technical School"
label var hs_GED_y1_clean "Has High School Degree"
label var coll_deg_y1_clean "Has College Degree"
label var cert_license_y1_clean "Has Professional Certificate"
label var educ_increase_y1_clean "Increased Education"


gen educ_increase_clean = 1
gen pos_ed_outcome_clean = 1


eststo clear 	
eststo _filler: qui reg earnings_increase const


esttab _filler _filler _filler _filler _filler ///
using "ADM - Education.tex", replace ///
keep(const) drop(const) ///
mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff.") ///
nogaps nonotes noobs b(a2) frag

*Fill in table	
foreach var in $education {
	eststo clear 	
	qui replace x = const
	
	
	qui mdesc `var'_y1_clean
	replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons
	eststo _b1: quietly reg `var'_y1_clean x, nocons r 
	eststo _b2: quietly reg `var'_y1_clean x if treat_status == 1, nocons r
	eststo _b3: qui reg `var'_y1_clean x if treat_status == 0, nocons r			
	quietly replace x = treat_status
	eststo _b4: qui reghdfe `var'_y1_clean x `var'_clean $controls bline_missing, absorb($fe) vce(robust)

	esttab _b* using "ADM - Education.tex", append ///
	keep(x) varlabels(x "`: var label `var'_y1_clean'") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%4.2f)) b(pattern(0 1 1 1 0) fmt(%4.2f))  b(pattern(1 0 0 0 0) fmt(%4.0f)) " se(par fmt(%4.2f) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01)  ///
	collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
}	




**********************************************************************
* Table A.22 Financial Managment
**********************************************************************
* rename some variables so bline and y1 names align






label var acct_y1_clean "Any Bank Account"
label var acct_amt_y1_clean "Amount in Bank Account"
label var hh_inc_lastyear_y1_clean "HH Income (\\\$)"
label var childsup_amt_y1_clean "Child Support (\\\$)"
label var ff_gifts_y1_clean "Gifts (\\\$)"
label var food_pantry_y1_clean "Any Food Pantry"
label var claimed_eitc_y1_clean "Claimed EITC"
label var payday  "Any Dayday Loan"
label var payday_multiple_y1_clean  "Multiple Payday Loans"
label var rollover_y1_clean "Any Rollover from a Payday Loan"
label var liabilities_y1_clean "Liabilities (\\\$)"
label var cc_debt_y1_clean "Any HH Credit Card Debt"
label var cc_debt_amt_y1_clean "HH Credit Card Debt (\\\$)"
label var budget_y1_clean "Any HH Budget"


foreach var in $finance $benefits {
	replace `var'_clean = . if `var'_clean < 0
	replace `var'_y1_clean = . if `var'_y1_clean < 0
}


replace wic_amt_y1_clean = 0 if wic_y1_clean == 2

eststo clear 	
eststo _filler: qui reg earnings_increase const


esttab _filler _filler _filler _filler _filler ///
using "ADM - Finance.tex", replace ///
keep(const) drop(const) ///
mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff.") ///
nogaps nonotes noobs b(a2) frag

*Fill in table	
foreach var in $finance {
	eststo clear 	
	qui replace x = const
	
	replace bline_missing = missing(`var'_clean)
	qui sum `var'_clean, d
	qui replace `var'_clean = `r(mean)' if missing(`var'_clean)
	
	qui mdesc `var'_y1_clean
	qui replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons
	eststo _b1: quietly reg `var'_y1_clean x, nocons r 
	eststo _b2: quietly reg `var'_y1_clean x if treat_status == 1, nocons r
	eststo _b3: quietly reg `var'_y1_clean x if treat_status == 0, nocons r			
	quietly replace x = treat_status
	eststo _b4: qui reghdfe `var'_y1_clean x `var'_clean $controls bline_missing, absorb($fe) vce(robust)

	
	if inlist("`var'_y1_clean","acct_amt_y1_clean", "hh_inc_lastyear_y1_clean", "childsup_amt_y1_clean", "ff_gifts_y1_clean", "liabilities_y1_clean", "cc_debt_amt_y1_clean") {
		local dig = 0
	}
	if !inlist("`var'_y1_clean","acct_amt_y1_clean", "hh_inc_lastyear_y1_clean", "childsup_amt_y1_clean", "ff_gifts_y1_clean", "liabilities_y1_clean", "cc_debt_amt_y1_clean") {
		local dig = 2
	}
	
	
	esttab _b* using "ADM - Finance.tex", append ///
	keep(x) varlabels(x "`: var label `var'_y1_clean'") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%9.`dig'fc)) b(pattern(0 1 1 1 0) fmt(%9.`dig'fc)) b(pattern(1 0 0 0 0) fmt(%4.0f)) " se(par fmt(%9.`dig'fc) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
}

	

	

*
**********************************************************************
* Table A.24 - Hope
**********************************************************************
	* This needs to be combined with the Executive Control tex file for panel B.
global hope hope_total_increase hope_agency_increase hope_pathway_increase  
 
label var hope_pathway_increase "Increase in Pathway Hope"
label var hope_agency_increase "Increase in Agency Hope"
eststo clear 	
qui reg earnings_increase const
eststo _filler

esttab _filler _filler _filler _filler _filler ///
using "ADM - Hope.tex", replace ///
keep(const) drop(const) ///
		mtitles("Sample Size" "Full Sample" "Control" "Treatment" "Adj. Diff.") ///
nogaps nonotes noobs b(a2) frag

*Fill in table	
foreach var in $hope {
	eststo clear 	
	qui replace x = const
	
	qui mdesc `var'
	replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons
	eststo _b1: quietly reg `var' x, nocons r 
	eststo _b2: quietly reg `var' x if treat_status == 1, nocons r				
	eststo _b3: quietly reg `var' x if treat_status == 0, nocons r				
	quietly replace x = treat_status
	eststo _b4: quietly reghdfe `var' x $controls , absorb($fe) vce(robust)

	esttab _b* using ///
	"ADM - Hope.tex", append ///
	keep(x) varlabels(x "`: var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1) fmt(%4.2f)) b(pattern(0 1 1 1 0) fmt(%4.2f)) b(pattern(1 0 0 0 0) fmt(%4.0f)) " se(par fmt(%4.2f) pattern(0 0 0 0 1))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01)  ///
	collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
}






**********************************************************************
* Earning Outcomes
**********************************************************************
global earning_outcomes r_inc_lastmonth_y1_clean hh_inc_lastmonth_y1_clean hh_inc_lastyear_y1_clean ///
			job_lastmonth_y1_clean hourly_wage2_y1_clean hours_main_y1_clean hours_perwk_y1_clean hours_lastwk_y1_clean 
label var r_inc_lastmonth_y1_clean "Earnings Last Month"
label var hh_inc_lastmonth_y1_clean "Household Earnings Last Month"
label var hh_inc_lastyear_y1_clean  "Household Income Last Year"
label var job_lastmonth_y1_clean "Worked in Past Month"
label var hourly_wage2_y1_clean "Hourly Wage Last Month"
label var hours_main_y1_clean "Hours Usually Worked per Week "
label var hours_perwk_y1_clean "Hours Worked per Week Last Year"
label var hours_lastwk_y1_clean "Hours Worked Last Week"	
		eststo clear 	
		qui reg earnings_increase const
		eststo _filler
	 
		esttab _filler _filler _filler _filler _filler ///
		using "ADM - Earnings Outcomes.tex", replace ///
		keep(const) drop(const) ///
		mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff.") ///
		nogaps nonotes noobs b(a2) frag
		
		*Fill in table	
		foreach var in $earning_outcomes {
			eststo clear 	
			qui replace x = const
			
			qui mdesc `var'
			replace total = r(total)-r(miss)
			eststo _b0: quietly reg total x , nocons
			eststo _b1: qui reg `var' x, nocons r 
			eststo _b2: qui reg `var' x if treat_status == 1, nocons r		
			eststo _b3: qui reg `var' x if treat_status == 0, nocons r				
			quietly replace x = treat_status
			eststo _b4: quietly reghdfe `var' x $controls , absorb($fe) vce(robust)
			


			esttab _b* using ///
			"ADM - Earnings Outcomes.tex", append ///
			keep(x) varlabels(x "`: var label `var''") se ///
			cells("b(star pattern(0 0 0 0 1) fmt(%4.2f)) b(pattern(1 1 1 1 0) fmt(%4.2f)) " se(par fmt(%4.2f) pattern(0 0 0 0 1))) ///
			starlevel(* 0.10 ** 0.05 *** 0.01)  ///
			collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
		}


