/*------------------------------------------------------------------------------
Master - Rochester Bridges to Success
	*Started: 08/30/21
	*Updated: 03/13/2026
	*Author: Tim Spilde
	The goal of this file is to build a do file that takes in only raw data and 
	builds the final datasets & output files.
	
	* This do file creates all of the output in the official JPUBE manuscript
------------------------------------------------------------------------------*/
*of those that can be categorized.
clear
set more off

		global rawbase_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/PII/Raw Data for Analysis/Baseline Data"
		global rawyl_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/PII/Raw Data for Analysis/Follow-up 1 Interim Surveys"
		global raw_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/Raw-Data"
		global raw_experian "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/Raw-Data/Experian"
		global pii_match_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/PII/Match for Analysis"
		global pii_surveys_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/PII/Raw Data for Analysis"
		global pii_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/PII/Match for Analysis"
		global pii_loc_2     "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/PII/Match for Analysis Cohort 2"
		global piidta_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/PII/Match for Analysis/DTA Files"
		global pii_experian "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/PII/Experian Data Request/"
		global do_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Do Files"
		global dta_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/DTA Files"
		global output_loc "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Stata Outputs"
		global overleaf "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Overleaf"
		global ui  "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/UI Analysis Only"
		global ui_do "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/UI Analysis Only/do_files"
		
		global tim "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim"
		global jaq "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/PII/Jacqueline"
	
		global Figures "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Figures_JPUBE"
		global geocode "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/Raw-Data/Infutor_0922/geocode/"
		global crime "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/Raw-Data/Infutor_0922/crime"
	
	*Identifiable data (raw data) subfolder (data used for analysis)
		global ID_subfolder "Data for Analysis"

	*File Name globals
		global survey_new "New Forms 7.3.2018_USE.xlsx"
		global survey_old "Old Form Data - Thru 12.19.2017_USE.xlsx"
		global Cap60 "Cap60 Randomization Results 7.3.2018.xlsx"
		global david_randomizer "Original Randomization List - David's Randomizer"
		
**#
	global demographic "Demographics 7.17.2018"
		*global eval_demographic "Eval Demographics 4.9.2018_USE.xlsx"
		*global comp_demographic "Comp Demographics 4.9.2018_USE.xlsx"

	*Setting our working directory
		cd "$dofileDTA"

/*------------------------------------------------------------------------------
Set color scheme
------------------------------------------------------------------------------*/
* This code will set the scheme for figures to be LEO
do "${tim}/Side Tasks/Color Scheme.do"
	
/*------------------------------------------------------------------------------
Macros
------------------------------------------------------------------------------*/
	cd "$do_loc"

*1. Globals Index
	do "DO_Globals_Index.do"
	
/*------------------------------------------------------------------------------
SSN Updates
------------------------------------------------------------------------------*/	
** There was a follow up survey to target people who we do not have a full SSN.
** This section cleans the follow up survey and updates to SSN for experian.

* Clean data for both cohorts to be sent to Experian. The data should contain name, addresses, DOB, and SSN if available.
* The resulting Do files are the files that are sent to Experian to pull new quarters.
	do "${pii_experian}/DO Files/bridgestosuccess_experian_datamaker.do" // Cohort 1
	do "${pii_experian}/DO Files/bridgestosuccess_experian_datamaker_cohort2.do" //  Cohort 2

* Clean the data such that the experian ID can be linked to raw survey data. This seperate file is to ensure the data being sent to Experian does not change.
* These flies will be used in "DO_Merge.do" "DO_Merge_2.do" to attched Experain ID. This is useful because we can attach SSN to de-identified data when needed. 
	do "${pii_experian}/DO Files/bridgestosuccess_experian_merge_files.do"
/*-----------------------------------------------------------------------------
Files Dealing with PII - Only attempt to run these if you have access to the PII folder
-------------------------------------------------------------------------------*/

*1. Merge = Combines survey data with randomization and demographic data from Cap60.
	*Should produce a matched file in the PII folder containing names, addresses. 
	*Should also produce a matched file with all PII removed in the De-Identified folder.
	*Merge do file located in PII > Match for Analysis
	cd "$pii_loc/Do Files"
	do "DO_Merge.do" // cohort 1 - 299 obs
	* PAP Specifies 300 people.See do file for detials on dropped obs.
	
	cd "$pii_loc_2"
	do "DO_Merge_2.do" // cohort 2
	

/*------------------------------------------------------------------------------
Data Preparation for cohort 1 & 2 / Cleaning - All files in this section use De-Identified Information
------------------------------------------------------------------------------*/

	cd "$do_loc"

*1. Cleaning
	do "DO_Cleaning.do" // cohort 1 only
	cd "$do_loc"
	do "DO_Cleaning_2.do" // cohort 2 only
*2. Consumption Imputation
	*do "DO_Imputation.do" // cohort 1 & 2



/*------------------------------------------------------------------------------
Preparing year-1 follow-up survey data for analysis
------------------------------------------------------------------------------*/

 *** Cohort 1
*Files using PII:	

	cd "$pii_loc/Do Files"

	*1. Cleaning interim surveys
	do "DO_Clean Final.do"
		
	cd "$pii_loc/Do Files"
	*2. Merge with baseline surveys 
	*Creates one version in PII folder and one in De-Identified.
	do "DO_Merge Bline Final.do"
	* 100% Match rate for follow up surveys. We lost 37 people due to not responding.
*Files with de-identified:

	cd "$do_loc"
	*3. Generate variables for analysis using info from both baseline and follow-up
	do "DO_Outcome Variables.do"

	
	
 *** Cohort 2	
* A general survey was given to people from both cohorts who had not originally givent their SSN.
* There are 10 people in this survey from cohort 2. (1 person is dropped because they were randomized in covid & Prob(treat) = 1)

	* 1) Clean the follow up survey for people in cohort 2. 
	cd "$pii_loc_2"
	do "DO_Clean Final_c2.do"
	
	* 2) Merge with baseline surveys
	*Creates one version in PII folder and one in De-Identified.
	cd "$pii_loc_2"
	do "DO_Merge_Bline_Final_c2.do"
	* 100% Match rate for follow up surveys. Gain 9 observations for survey outcomes.
	* 3) Create outcomes
	cd "$do_loc"
	*3. Generate variables for analysis using info from both baseline and follow-up
	do "DO_Outcome Variables c2.do"
	
	
/*------------------------------------------------------------------------------
Main Figures
------------------------------------------------------------------------------*/	

	* Figure 1
	* Timeseries Plot - Status Over Months Since Baseline
	do "${tim}/Reports/Do Files/grad_rates.do"
	
	* Figure 2
	* Bar Chart with Proportion for Sample w/ each goal
	do "${tim}/Reports/Do Files/bline_goals.do"

	* Figure 3
	* Average $ received by Category
	do "${tim}/Reports/Do Files/Incentives_categories.do" // this is the original version with no patterns
	* "Figure3_JPUBE.do" run this code in python to get the official figure
	
	
	* Figure 4
	* Baseline Score vs Most Recent Score Scatter Plot
	do "${tim}/Reports/Do Files/progress_by_goal.do"
	

/*------------------------------------------------------------------------------
Infutor
------------------------------------------------------------------------------*/
	* This section does not have all infutor files. Some files require Geocoding,
	* which is hard on the front end.
	* Please see "${geocode}/infutor_master.do"
	
	cd "$geocode"
	* Create outcomes from tract level results
	do "B2S_tract_outcomes.do"

	
/*------------------------------------------------------------------------------
UI Analysis
------------------------------------------------------------------------------*/

	* From UI data, we want two files. 1) A file that creates 1 year outcomes to be comparable with the 
	* survey results. 2) A time series file to leverage the quarterly frequency. The first file of the UI 
	* sequence does some basic cleaning to ensure that both files are being created the same. When Tim first did this,
	* there were discrepencies between files. Those have been fixed.
	

	do "$ui_do/ui_match_JPUBE.do"	// Matches SSN from our sample with dataset from NY admin data
	do "$ui_do/ui_create_outcomes_JPUBE.do" // This is baseline measures of UI income, abd multiple followup outcomes
	do "$ui_do/ui_figures_JPUBE.do" // This creates quarterly time series figures
	

	
/*------------------------------------------------------------------------------
Other Outcomes
------------------------------------------------------------------------------*/	

	*Heterogeneous Effects
	
	*do "$tim/Hetro/RRS_split.do" // estimates 1 and 3 year effects by hihg/low employability at baseline\
		* Do not run in CRC - too taxing on system. Run htorugh back end with shell file.
	do "$tim/Hetro/hetro_effects.do"

	* Experian Credit Scores
	do "$tim/Experian/do/DO_experian.do"
	
	* Executive Control
	do "$tim/Executive Control/Executive_Control.do"
	
	* Benefits
	do "${tim}/public_benefits.do"
	

/*------------------------------------------------------------------------------
Year 1 Analysis
------------------------------------------------------------------------------*/
	* The analsys section is seperated into two parts. The first do file is
	* for outcomes that involve any UI data. The second file is for any survey related questions.
	
	*1. Run analysis to create tables of means and regression results
	do "$tim/balance_tables_JPUBE.do" // balance tables
		* The balance needs to run at the end. It pulls in data created in previous do files
		* that extablish different sample (ODTA, UI, etc.)
	do "$tim/outcomes_employment_JPUBE.do" // tables with main employment outcomes 
	
	do "$tim/outcomes_survey_JPUBE.do"
	

********************************************************************************
* This is the end of the master do file. All figures and tables created in the 
* JPUBE are created have been created
*********************************************************************************
