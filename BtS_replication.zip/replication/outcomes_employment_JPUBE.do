/*

outcomes_employment_JPUBE.do

This creates the tables for the main employment outcomes_employment	
	Main Table 3
	Table A10, A11, A12

*/

scalar reps = 1000



set seed 8957825

global ui  "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/UI Analysis Only"
global tim "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim"

use  "${ui}/dta_clean/ui_panel_2023.dta", clear


cd $Figures

qui gen const = 1
qui gen x = .
qui gen total = .
qui gen p_diff = .
gen z = .
global fe randomization_group month_year months_btwn_surveys_cat
global controls female quarterly_r_earnings married_clean white black other hispanic hs_GED_clean college_clean some_college_clean nohs_clean missing_survey

replace treat_status = treatment_final if missing(treat_status)
label var earnings_increase_ui_12 "Earning Increase Dummy"

rename earnigns_y1_com earnings_y1_com

global working working_y1_com working_ui_04 working_ui_12
global earnings earnings_y1_com earnings_ui_04 earnings_ui_12 earnings_increase_ui_12
global earnings_increase earnings_increase_com earnings_increase_ui_04 earnings_increase_ui_12
global earnings_fpl fpl_y1_com fpl_ui_04 fpl_ui_12


global panel1 working_y1_com earnings_y1_com earnings_increase_com   fpl_y1_com
global panel2 working_ui_04  earnings_ui_04  earnings_increase_ui_04 fpl_ui_04
global panel3 working_ui_12  earnings_ui_12  earnings_increase_ui_12 fpl_ui_12

gen cohortXmonth_year = month_year * 10 + cohort

foreach var in $working {
label var `var' "Employed"
}
foreach var in $earnings {
label var `var' "Quarterly Earnings (\\\$)"
}
foreach var in $earnings_increase {
label var `var' "Earnings Increased"
}


gen year_1y = year_today + 1
gen year_3y = year_today + 3

* hardcode in poverty level data by year and household size

gen fpl_baseline = .

* ---------- 2017 ----------
qui replace fpl_baseline = 12060 if num_hh == 1  & year_today == 2017
qui replace fpl_baseline = 16240 if num_hh == 2  & year_today == 2017
qui replace fpl_baseline = 20420 if num_hh == 3  & year_today == 2017
qui replace fpl_baseline = 24600 if num_hh == 4  & year_today == 2017
qui replace fpl_baseline = 28780 if num_hh == 5  & year_today == 2017
qui replace fpl_baseline = 32960 if num_hh == 6  & year_today == 2017
qui replace fpl_baseline = 37140 if num_hh == 7  & year_today == 2017
qui replace fpl_baseline = 41320 if num_hh == 8  & year_today == 2017
qui replace fpl_baseline = 4132 + (num_hh - 8)*4180 if num_hh > 8 & year_today == 2017

* ---------- 2018 ----------
qui replace fpl_baseline = 12140 if num_hh == 1  & year_today == 2018
qui replace fpl_baseline = 16460 if num_hh == 2  & year_today == 2018
qui replace fpl_baseline = 20780 if num_hh == 3  & year_today == 2018
qui replace fpl_baseline = 25100 if num_hh == 4  & year_today == 2018
qui replace fpl_baseline = 29420 if num_hh == 5  & year_today == 2018
qui replace fpl_baseline = 33740 if num_hh == 6  & year_today == 2018
qui replace fpl_baseline = 38060 if num_hh == 7  & year_today == 2018
qui replace fpl_baseline = 42380 if num_hh == 8  & year_today == 2018
qui replace fpl_baseline = 42380 + (num_hh - 8)*4320 if num_hh > 8 & year_today == 2018
 
* ---------- 2020 ----------
qui replace fpl_baseline = 12760 if num_hh == 1 & year_today == 2020
qui replace fpl_baseline = 17240 if num_hh == 2 & year_today == 2020
qui replace fpl_baseline = 21720 if num_hh == 3 & year_today == 2020
qui replace fpl_baseline = 26200 if num_hh == 4 & year_today == 2020
qui replace fpl_baseline = 30680 if num_hh == 5 & year_today == 2020
qui replace fpl_baseline = 35160 if num_hh == 6 & year_today == 2020
qui replace fpl_baseline = 39640 if num_hh == 7 & year_today == 2020
qui replace fpl_baseline = 44120 if num_hh == 8 & year_today == 2020
qui replace fpl_baseline = 44120 + (num_hh - 8) * 4480 if num_hh > 8 & year_today == 2020 



gen fpl_y1 = .

* ---------- 2018 ----------
qui replace fpl_y1 = 12140 if num_hh == 1  & year_1y == 2018
qui replace fpl_y1 = 16460 if num_hh == 2  & year_1y == 2018
qui replace fpl_y1 = 20780 if num_hh == 3  & year_1y == 2018
qui replace fpl_y1 = 25100 if num_hh == 4  & year_1y == 2018
qui replace fpl_y1 = 29420 if num_hh == 5  & year_1y == 2018
qui replace fpl_y1 = 33740 if num_hh == 6  & year_1y == 2018
qui replace fpl_y1 = 38060 if num_hh == 7  & year_1y == 2018
qui replace fpl_y1 = 42380 if num_hh == 8  & year_1y == 2018
qui replace fpl_y1 = 42380 + (num_hh - 8)*4320 if num_hh > 8 & year_1y == 2018
 
* ---------- 2019 ----------
qui replace fpl_y1 = 12490 if num_hh == 1  & year_1y == 2019
qui replace fpl_y1 = 16910 if num_hh == 2  & year_1y == 2019
qui replace fpl_y1 = 21330 if num_hh == 3  & year_1y == 2019
qui replace fpl_y1 = 25750 if num_hh == 4  & year_1y == 2019
qui replace fpl_y1 = 30170 if num_hh == 5  & year_1y == 2019
qui replace fpl_y1 = 34590 if num_hh == 6  & year_1y == 2019
qui replace fpl_y1 = 39010 if num_hh == 7  & year_1y == 2019
qui replace fpl_y1 = 43430 if num_hh == 8  & year_1y == 2019
qui replace fpl_y1 = 43430 + (num_hh - 8)*4420 if num_hh > 8 & year_1y == 2019
 
* ---------- 2021 ----------
qui replace fpl_y1 = 12880 if num_hh == 1  & year_1y == 2021
qui replace fpl_y1 = 17420 if num_hh == 2  & year_1y == 2021
qui replace fpl_y1 = 21960 if num_hh == 3  & year_1y == 2021
qui replace fpl_y1 = 26500 if num_hh == 4  & year_1y == 2021
qui replace fpl_y1 = 31040 if num_hh == 5  & year_1y == 2021
qui replace fpl_y1 = 35580 if num_hh == 6  & year_1y == 2021
qui replace fpl_y1 = 40120 if num_hh == 7  & year_1y == 2021
qui replace fpl_y1 = 44660 if num_hh == 8  & year_1y == 2021
qui replace fpl_y1 = 44660 + (num_hh - 8)*4540 if num_hh > 8 & year_1y == 2021




gen fpl_y3 = .

* 2020 Poverty Guidelines
qui replace fpl_y3 = 12760 if num_hh == 1 & year_3y == 2020
qui replace fpl_y3 = 17240 if num_hh == 2 & year_3y == 2020
qui replace fpl_y3 = 21720 if num_hh == 3 & year_3y == 2020
qui replace fpl_y3 = 26200 if num_hh == 4 & year_3y == 2020
qui replace fpl_y3 = 30680 if num_hh == 5 & year_3y == 2020
qui replace fpl_y3 = 35160 if num_hh == 6 & year_3y == 2020
qui replace fpl_y3 = 39640 if num_hh == 7 & year_3y == 2020
qui replace fpl_y3 = 44120 if num_hh == 8 & year_3y == 2020
qui replace fpl_y3 = 44120 + (num_hh - 8) * 4480 if num_hh > 8 & year_3y == 2020

* 2021 Poverty Guidelines
qui replace fpl_y3 = 12880 if num_hh == 1 & year_3y == 2021
qui replace fpl_y3 = 17420 if num_hh == 2 & year_3y == 2021
qui replace fpl_y3 = 21960 if num_hh == 3 & year_3y == 2021
qui replace fpl_y3 = 26500 if num_hh == 4 & year_3y == 2021
qui replace fpl_y3 = 31040 if num_hh == 5 & year_3y == 2021
qui replace fpl_y3 = 35580 if num_hh == 6 & year_3y == 2021
qui replace fpl_y3 = 40120 if num_hh == 7 & year_3y == 2021
qui replace fpl_y3 = 44660 if num_hh == 8 & year_3y == 2021
qui replace fpl_y3 = 44660 + (num_hh - 8) * 4540 if num_hh > 8 & year_3y == 2021

* 2023 Poverty Guidelines
qui replace fpl_y3 = 14580 if num_hh == 1 & year_3y == 2023
qui replace fpl_y3 = 19720 if num_hh == 2 & year_3y == 2023
qui replace fpl_y3 = 24860 if num_hh == 3 & year_3y == 2023
qui replace fpl_y3 = 30000 if num_hh == 4 & year_3y == 2023
qui replace fpl_y3 = 35140 if num_hh == 5 & year_3y == 2023
qui replace fpl_y3 = 40280 if num_hh == 6 & year_3y == 2023
qui replace fpl_y3 = 45420 if num_hh == 7 & year_3y == 2023
qui replace fpl_y3 = 50560 if num_hh == 8 & year_3y == 2023
qui replace fpl_y3 = 50560 + (num_hh - 8) * 5140 if num_hh > 8 & year_3y == 2023

foreach var in y1_com ui_04 ui_12 {
	qui gen fpl_`var' = .
	if !inlist("`var'", "ui_12") {
		di "`var'"
		di "ui y1"
	replace fpl_`var' = 1 if earnings_`var' > fpl_y1/4
	}
	if inlist("`var'", "ui_12") {
		di "`var'"
		di "ui12"
	replace fpl_`var' = 1 if earnings_`var' > fpl_y3/4
	}
	replace fpl_`var' = 0 if missing(fpl_`var')
	replace fpl_`var' = . if missing(earnings_`var')
	replace fpl_`var' = . if missing(num_hh)	
	
	label var fpl_`var' "Earnings Above Poverty Line"
}


foreach var in bl_com ui {
	qui gen fpl_`var' = .
	replace fpl_`var' = 1 if earnings_`var' > fpl_baseline/4
	
	replace fpl_`var' = 0 if missing(fpl_`var')
	replace fpl_`var' = . if missing(earnings_`var')
	replace fpl_`var' = . if missing(num_hh)
	
	label var fpl_`var' "Earnings Above Poverty Line"
}


/************************************************************
TABLE 3
************************************************************/
	
************* Main table (logit for dichotomous, linear for continuous)	

	qui reg quarterly_r_earnings const
	eststo _filler
	esttab _filler _filler _filler _filler _filler _filler using ///
	"ADM - Employment Y1 UI.tex", replace ///
	keep(const) drop(const) ///
	nogaps nonotes noobs  b(a2) frag ///
	mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value")
	


	foreach var in  $panel1 $panel2 $panel3 {
	
	
	di "apple estimation for outcome: `var'"
	
	local lag
	local head
	* The dollar variables rounded to dollar, precent rounded to 0.01 place
	if inlist("`var'", "earnings_y1_com", "earnings_ui_04", "earnings_ui_12") {
		local dig 0
	}
	if !inlist("`var'", "earnings_y1_com", "earnings_ui_04", "earnings_ui_12") {
		local dig 2
	}
	
	
	if "`var'" == "working_y1_com" {
		local lag working_bl_com
		local head   prehead("\textbf{1 Year Results (Survey + UI)}\\") 
	}
	if "`var'" == "working_ui_04" {
		local lag working_ui
		local head   prehead("\textbf{1 Year Results (UI)}\\") 
	}
	if "`var'" == "working_ui_12" {
		local lag working_ui
		local head   prehead("\textbf{3 Year Results (UI)}\\") 
	}	
	if "`var'" == "fpl_y1_com" {
		local lag fpl_bl_com
	}
	if "`var'" == "fpl_ui_04" {
		local lag fpl_ui
	}
	if "`var'" == "fpl_ui_12" {
		local lag fpl_ui
	}	
	
	eststo clear	
	quietly replace x = const
	qui mdesc `var'
	qui replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons	
	eststo _b1: quietly reg `var' x, nocons r 
	eststo _b2: quietly reg `var' x if treatment_final == 1, nocons r			
	eststo _b3: quietly reg `var' x if treatment_final == 0, nocons r
	quietly replace x = treatment_final
	
	if "`var'" == "earnings_y1_com" | "`var'" == "earnings_ui_04" | "`var'" == "earnings_ui_12" {
		eststo _b4: qui reghdfe `var' x `lag' $controls , absorb(cohortXmonth_year months_btwn_surveys_cat) vce(robust)
		ritest treatment_final (_b[treatment_final]),  strata(randomization_group)  reps(`=reps'): reghdfe `var' treatment_final `lag' $controls , vce(robust)  absorb(cohortXmonth_year months_btwn_surveys_cat)
		qui replace  p_diff = r(p)[1,1]
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons		
	}
	
	else {
		logit `var' x `lag' $controls i.cohortXmonth_year  i.months_btwn_surveys_cat, robust
		eststo _b4: margins, dydx(x) post
		scalar beta  = e(b)[1,1]
		scalar se    = sqrt(e(V)[1,1])
		replace z     = beta/se
		replace  p_diff  = 2*(1-normal(abs(z)))
		display "Coef = " beta "  SE = " se "  p = " p_diff	
		ritest treatment_final (_b[treatment_final]),  strata(randomization_group)  reps(`=reps'): logit `var' treatment_final `lag' $controls i.cohortXmonth_year i.months_btwn_surveys_cat , vce(robust)	
		qui replace  p_diff = r(p)[1,1]
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons		
	}

	qui esttab _b* using "ADM - Employment Y1 UI.tex", append ///
	keep(x) varlabels(x "`:var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 1 1 1 0 0) fmt(%9.`dig'fc)) b(pattern(1 0 0 0 0 0) fmt(%4.0f)) b(pattern(0 0 0 0 0 1)  fmt(%4.2f))" se(par fmt(%4.`dig'f) pattern(0 0 0 0 1 0))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nodepvars nonum nomtitle nogaps nonotes nolines frag noobs `head'
	}
		
		
/************************************************************
TABLE A.10 OLS w/ Strat FE
************************************************************/



*****All linear, analytical SEs	with strata FE
	qui reg quarterly_r_earnings const
	eststo _filler
	esttab _filler _filler _filler _filler _filler _filler using ///
	"ADM - Employment Y1 UI_linear_fe.tex", replace ///
	keep(const) drop(const) ///
	nogaps nonotes noobs  b(a2) frag ///
	mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value")

	foreach var in  $panel1 $panel2 $panel3 {
		
	local lag
	local head
	* The dollar variables rounded to dollar, precent rounded to 0.01 place
	if inlist("`var'", "earnings_y1_com", "earnings_ui_04", "earnings_ui_12") {
		local dig 0
	}
	if !inlist("`var'", "earnings_y1_com", "earnings_ui_04", "earnings_ui_12") {
		local dig 2
	}
	
	
	if "`var'" == "working_y1_com" {
		local lag working_bl_com
		local head   prehead("\textbf{1 Year Results (Survey + UI)}\\") 
	}
	if "`var'" == "working_ui_04" {
		local lag working_ui
		local head   prehead("\textbf{1 Year Results (UI)}\\") 
	}
	if "`var'" == "working_ui_12" {
		local lag working_ui
		local head   prehead("\textbf{3 Year Results (UI)}\\") 
	}
	
	if "`var'" == "fpl_y1_com" {
		local lag fpl_bl_com
	}
	if "`var'" == "fpl_ui_04" {
		local lag fpl_ui
	}
	if "`var'" == "fpl_ui_12" {
		local lag fpl_ui
	}	
	
	
	eststo clear	
	quietly replace x = const
	qui mdesc `var'
	qui replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons	
	eststo _b1: quietly reg `var' x, nocons r 
	eststo _b2: quietly reg `var' x if treatment_final == 1, nocons r			
	eststo _b3: quietly reg `var' x if treatment_final == 0, nocons r
	quietly replace x = treatment_final
	eststo _b4: qui reghdfe `var' x `lag' $controls , absorb($fe) vce(robust)
	qui replace  p_diff = 2*(1-normal(abs(_b[x] / _se[x])))
	qui replace x = const
	eststo _b5: qui reg p_diff x, nocons
	qui esttab _b* using "ADM - Employment Y1 UI_linear_fe.tex", append ///
	keep(x) varlabels(x "`:var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 1 1 1 0 0) fmt(%9.`dig'fc)) b(pattern(1 0 0 0 0 0) fmt(%4.0f)) b(pattern(0 0 0 0 0 1)  fmt(%4.2f))" se(par fmt(%4.`dig'f) pattern(0 0 0 0 1 0))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nodepvars nonum nomtitle nogaps nonotes nolines frag noobs `head'
	}

	

/************************************************************
TABLE A.11 No accounting for stratification
************************************************************/
***** 	
	
	qui reg quarterly_r_earnings const
	eststo _filler
	esttab _filler _filler _filler _filler _filler _filler using ///
	"ADM - Employment Y1 UI noFE.tex", replace ///
	keep(const) drop(const) ///
	nogaps nonotes noobs  b(a2) frag ///
	mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value")
	


	foreach var in  $panel1 $panel2 $panel3 {
		
	local lag
	local head
	* The dollar variables rounded to dollar, precent rounded to 0.01 place
	if inlist("`var'", "earnings_y1_com", "earnings_ui_04", "earnings_ui_12") {
		local dig 0
	}
	if !inlist("`var'", "earnings_y1_com", "earnings_ui_04", "earnings_ui_12") {
		local dig 2
	}
	
	
	if "`var'" == "working_y1_com" {
		local lag working_bl_com
		local head   prehead("\textbf{1 Year Results (Survey + UI)}\\") 
	}
	if "`var'" == "working_ui_04" {
		local lag working_ui
		local head   prehead("\textbf{1 Year Results (UI)}\\") 
	}
	if "`var'" == "working_ui_12" {
		local lag working_ui
		local head   prehead("\textbf{3 Year Results (UI)}\\") 
	}
	if "`var'" == "fpl_y1_com" {
		local lag fpl_bl_com
	}
	if "`var'" == "fpl_ui_04" {
		local lag fpl_ui
	}
	if "`var'" == "fpl_ui_12" {
		local lag fpl_ui
	}	
	
	eststo clear	
	quietly replace x = const
	qui mdesc `var'
	qui replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons	
	eststo _b1: quietly reg `var' x, nocons r 
	eststo _b2: quietly reg `var' x if treatment_final == 1, nocons r			
	eststo _b3: quietly reg `var' x if treatment_final == 0, nocons r
	quietly replace x = treatment_final
	
	if "`var'" == "earnings_y1_com" | "`var'" == "earnings_ui_04" | "`var'" == "earnings_ui_12" {
		eststo _b4: qui reghdfe `var' x `lag' $controls , absorb(cohortXmonth_year months_btwn_surveys_cat) vce(robust)
		*ritest treatment_final (_b[treatment_final]),  strata(randomization_group)  reps(1000): reghdfe `var' treatment_final `lag' $controls , vce(robust)  absorb(cohortXmonth_year months_btwn_surveys_cat)
		qui replace  p_diff = 2*(1-normal(abs(_b[x] / _se[x])))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons		
	}
	
	else {
		logit `var' x `lag' $controls i.cohortXmonth_year  i.months_btwn_surveys_cat, robust
		eststo _b4: margins, dydx(x) post
		scalar beta  = e(b)[1,1]
		scalar se    = sqrt(e(V)[1,1])
		replace z     = beta/se
		replace  p_diff  = 2*(1-normal(abs(z)))
		display "Coef = " beta "  SE = " se "  p = " p_diff	
		*ritest treatment_final (_b[treatment_final]),  strata(randomization_group)  reps(1000): logit `var' treatment_final `lag' $controls i.cohortXmonth_year i.months_btwn_surveys_cat , vce(robust)	
		*qui replace  p_diff = r(p)[1,1]
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons		
	}

	qui esttab _b* using "ADM - Employment Y1 UI noFE.tex", append ///
	keep(x) varlabels(x "`:var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 1 1 1 0 0) fmt(%9.`dig'fc)) b(pattern(1 0 0 0 0 0) fmt(%4.0f)) b(pattern(0 0 0 0 0 1)  fmt(%4.2f))" se(par fmt(%4.`dig'f) pattern(0 0 0 0 1 0))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nodepvars nonum nomtitle nogaps nonotes nolines frag noobs `head'
	}
	
	


	
	
	
/* *****************************************************************************
Table A.12 IPW
*/ *****************************************************************************
	
logit treatment_final $controls i.cohortXmonth_year i.months_btwn_surveys_cat 


predict p_treat, pr
gen ipw = .
replace ipw = 1/p_treat if treatment_final == 1
replace ipw = 1/(1-p_treat) if treatment_final == 0

     qui sum p_treat if treatment_final == 1, d
	local tmean : display %4.2f r(mean)
     qui sum p_treat if treatment_final == 0, d
	local cmean : display %4.2f r(mean)
*twoway (histogram p_treat if treatment_final==1, color(green%30)) ///
*       (histogram p_treat if treatment_final==0, color(red%30)), ///
*       legend(order(1 "Treatment (`tmean')" 2 "Control (`cmean')" ))
	qui reg quarterly_r_earnings const
	eststo _filler
	esttab _filler _filler _filler _filler _filler _filler using ///
	"ADM - Employment Y1 UI ipw.tex", replace ///
	keep(const) drop(const) ///
	nogaps nonotes noobs  b(a2) frag ///
	mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value")

	drop ipw	
	
	foreach var in  $panel1 $panel2 $panel3 {
	
	local lag
	local head
	* The dollar variables rounded to dollar, precent rounded to 0.01 place
	if inlist("`var'", "earnings_y1_com", "earnings_ui_04", "earnings_ui_12") {
		local dig 0
	}
	if !inlist("`var'", "earnings_y1_com", "earnings_ui_04", "earnings_ui_12") {
		local dig 2
	}
	
	if "`var'" == "working_y1_com" {
		local lag working_bl_com
		local head   prehead("\textbf{1 Year Results (Survey + UI)}\\") 
	}
	if "`var'" == "working_ui_04" {
		local lag working_ui
		local head   prehead("\textbf{1 Year Results (UI)}\\") 
	}
	if "`var'" == "working_ui_12" {
		local lag working_ui
		local head   prehead("\textbf{3 Year Results (UI)}\\") 
	}
	if "`var'" == "fpl_y1_com" {
		local lag fpl_bl_com
	}
	if "`var'" == "fpl_ui_04" {
		local lag fpl_ui
	}
	if "`var'" == "fpl_ui_12" {
		local lag fpl_ui
	}	
	
	qui logit treatment_final $controls `lag' i.cohortXmonth_year i.months_btwn_surveys_cat  
	predict p_treat_`var', pr
	gen ipw_`var' = .
	replace ipw_`var' = 1/p_treat_`var' if treatment_final == 1
	replace ipw_`var' = 1/(1-p_treat_`var') if treatment_final == 0	
	
	
	eststo clear	
	quietly replace x = const
	qui mdesc `var'
	qui replace total = r(total)-r(miss)
	eststo _b0: quietly reg total x , nocons	
	eststo _b1: quietly reg `var' x, nocons r 
	eststo _b2: quietly reg `var' x if treatment_final == 1, nocons r			
	eststo _b3: quietly reg `var' x if treatment_final == 0, nocons r
	quietly replace x = treatment_final 
	
	if "`var'" == "earnings_y1_com" | "`var'" == "earnings_ui_04" | "`var'" == "earnings_ui_12" {
		eststo _b4:  reg `var' x  $controls `lag' i.cohortXmonth_year i.months_btwn_surveys_cat [pw=ipw_`var'], r
		qui replace  p_diff = 2*(1-normal(abs(_b[x] / _se[x])))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
	}
	
	else {
		logit `var' x $controls `lag' i.cohortXmonth_year i.months_btwn_surveys_cat [pw=ipw_`var'], r
		eststo _b4: margins, dydx(x) post
		scalar beta  = e(b)[1,1]
		scalar se    = sqrt(e(V)[1,1])
		replace z     = beta/se
		replace  p_diff  = 2*(1-normal(abs(z)))
		display "Coef = " beta "  SE = " se "  p = " p_diff	
		*ritest treatment_final (_b[treatment_final]),  strata(randomization_group)  reps(1000): logit `var' treatment_final `lag' $controls i.cohortXmonth_year i.months_btwn_surveys_cat , vce(robust)	
		*qui replace  p_diff = r(p)[1,1]
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons		
	}
	
	
	qui esttab _b* using "ADM - Employment Y1 UI ipw.tex", append ///
	keep(x) varlabels(x "`:var label `var''") se ///
	cells("b(star pattern(0 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 1 1 1 0 0) fmt(%9.`dig'fc)) b(pattern(1 0 0 0 0 0) fmt(%4.0f)) b(pattern(0 0 0 0 0 1)  fmt(%4.2f))" se(par fmt(%4.`dig'f) pattern(0 0 0 0 1 0))) ///
	starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nodepvars nonum nomtitle nogaps nonotes nolines frag noobs `head'
	}


	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
