****************************************************
* Setup
****************************************************

set seed 880004
scalar reps = 1000

use "${ui}/dta_clean/ui_panel_2023.dta", clear
cd "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim/Hetro/"

gen cohortXmonth_year = month_year * 10 + cohort
gen one = 1
eststo clear

****************************************************
* Globals
****************************************************

global controls female quarterly_r_earnings married_clean white black other hispanic ///
    college_clean some_college_clean nohs_clean hs_clean

global fe cohortXmonth_year randomization_group months_btwn_surveys_cat


****************************************************
* Subgroup Construction
****************************************************

* Race

label var black "Black"
gen not_black = !black
label var not_black "Not Black"

* Gender
label var female "Female"
gen male = !female
label var male "Male"

* Single mother
gen single_mom = female & num_workage_adults == 1 & num_kids > 0
label var single_mom "Single Mom"

gen not_single_mom = !single_mom
label var not_single_mom "Not Single Mom"

* Age split (median)
quietly summarize age, detail
gen abov_med_age = age > r(p50)
label var abov_med_age "Above Median Age"

gen below_med_age = !abov_med_age
label var below_med_age "Below Median Age"

* COVID timing
gen day_bline = date(baselinedate, "MDY")
format day_bline %td

* 22006 = March 13, 2020
gen post_covid = day_bline > 22006
label var post_covid "Enrolled Post Covid"

gen pre_covid = !post_covid
label var pre_covid "Enrolled Pre Covid"

* Cohort indicators
gen cohort1 = cohort == 1
label var cohort1 "Cohort 1"

gen cohort2 = cohort == 2
label var cohort2 "Cohort 2"

* Education
label var nohs_clean "No High School"

gen hs_clean = !nohs_clean
label var hs_clean "High School"

* Cohort × Education Interactions

gen c1_nohs = cohort1 & nohs_clean
label var c1_nohs "Cohort 1, No High School"

gen c1_hs = cohort1 & hs_clean
label var c1_hs "Cohort 1, High School"

gen c2_nohs = cohort2 & nohs_clean
label var c2_nohs "Cohort 2, No High School"

gen c2_hs = cohort2 & hs_clean
label var c2_hs "Cohort 2, High School"


global subgroups ///
    black not_black ///
    female male ///
    single_mom not_single_mom ///
    abov_med_age below_med_age ///
    nohs_clean hs_clean ///
    cohort1 cohort2 ///
    c1_nohs c1_hs c2_nohs c2_hs

****************************************************
* Control Group Avg Earnings
****************************************************

eststo clear 	
	qui reg earnings_increase one
	eststo _filler
 
	esttab _filler _filler ///
	using "Hetro Effects- Control Means.tex", replace ///
	keep(one) drop(one) ///
	mtitles("Y1 Earnings" "Y3 Earnings") ///
	nogaps nonotes noobs b(a2) frag
	eststo clear	
foreach var in $subgroups {
	eststo y1:  reg earnigns_y1_com one if `var' == 1 & treatment_final == 0, noconst
	eststo y3:  reg earnings_ui_12 one if `var' == 1 & treatment_final == 0, noconst
	
	esttab ** using "Hetro Effects- Control Means.tex", append ///
	varlabels(one "`: var label `var''") nostar ///
	cells("b(star pattern(1 1) fmt(%9.1fc))" ) ///
	collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag not ///
	
}
reg earnigns_y1_com one if  treatment_final == 0, noconst
reg earnings_ui_12 one if  treatment_final == 0, noconst
****************************************************
* Figure Construction
****************************************************
 
matrix R = J(18,2,.)
   matrix colnames R = "coef" "se"  
   matrix rownames R = "High Employability" "Low Employability" "Black" "Not Black" "Female" "Male" "Single Mom" "Not Single Mom" "Above Median Age" "Below Median Age"  "No High School" "High School" "Cohort 1" "Cohort 2" "Cohort 1, No High School" "Cohort 1, High School" "Cohort 2, No High School" "Cohort 2, High School"
    
    *these come from the do files in the hetro folder
    matrix R[1,1] = 0.022
    matrix R[1,2] = 0.071
    matrix R[2,1] = 0.146
    matrix R[2,2] = 0.060
    
    
   local i = 3
   local rownames ""  
   foreach var in black female single_mom abov_med_age nohs_clean cohort1 {

	qui: gen treat_high = 0
	qui: replace treat_high = 1 if (treatment_final == 1 & `var' == 1)
	qui: gen treat_low = 0
	qui: replace treat_low = 1 if (treatment_final == 1 & `var' == 0)    
    
	logit  working_y1_com treat_high treat_low treatment_final `var'  working_bl_com $controls i.cohortXmonth_year i.months_btwn_surveys_cat , vce(robust)	
	eststo _est_`var'_y`i': margins, dydx(treat_high treat_low) post

	matrix R[`i',1] =  _b[treat_high]
	matrix R[`i',2] =  _se[treat_high]
	matrix R[`=`i'+1',1] =  _b[treat_low]
	matrix R[`=`i'+1',2] =  _se[treat_low]	
	local i = `i' + 2
	drop treat_high treat_low
    }
  
foreach var of varlist c1_nohs c1_hs c2_nohs c2_hs {
	gen treatX`var' = treatment_final * `var'
}

logit  working_y1_com treatXc1_nohs treatXc1_hs treatXc2_nohs treatXc2_hs c1_nohs c1_hs c2_nohs c2_hs  working_bl_com $controls i.cohortXmonth_year i.months_btwn_surveys_cat , vce(robust)	
eststo _est_edcoh_y: margins, dydx(treatXc1_nohs treatXc1_hs treatXc2_nohs treatXc2_hs) post

 	matrix R[`i',1] =  _b[treatXc1_nohs]
	matrix R[`i',2] =  _se[treatXc1_nohs]
  	matrix R[`=`i'+1',1] =  _b[treatXc1_hs]
	matrix R[`=`i'+1',2] =  _se[treatXc1_hs]
	matrix R[`=`i'+2',1] =  _b[treatXc2_nohs]
	matrix R[`=`i'+2',2] =  _se[treatXc2_nohs]
	matrix R[`=`i'+3',1] =  _b[treatXc2_hs]
	matrix R[`=`i'+3',2] =  _se[treatXc2_hs]
    
  
matrix R = R'
matrix list R

coefplot matrix(R),  se(2) ///
	mcolor(LEOBlue) ciopts(lcolor(LEOBlue)) ///
	xline(0) xtitle("Subgroup Treatment Effect") xlabel(-.3(.1).7)
graph export "hetro_graph_y1.png", replace
	
	
	

matrix Y = J(18,2,.)
   matrix colnames Y = "coef" "se"  
   matrix rownames Y = "High Employability" "Low Employability" "Black" "Not Black" "Female" "Male" "Single Mom" "Not Single Mom" "Above Median Age" "Below Median Age"  "No High School" "High School" "Cohort 1" "Cohort 2" "Cohort 1, No High School" "Cohort 1, High School" "Cohort 2, No High School" "Cohort 2, High School"
    
    *these come from the do files in the hetro folder
    matrix Y[1,1] = 0.125
    matrix Y[1,2] = 0.071
    matrix Y[2,1] = 0.0486
    matrix Y[2,2] = 0.063

    
   local i = 3
   local rownames ""  
   foreach var in black female single_mom abov_med_age nohs_clean cohort1 {


	qui: gen treat_high = 0
	qui: replace treat_high = 1 if (treatment_final == 1 & `var' == 1)
	qui: gen treat_low = 0
	qui: replace treat_low = 1 if (treatment_final == 1 & `var' == 0)    
    
	logit  working_ui_12 treat_high treat_low treatment_final `var'  working_ui $controls i.cohortXmonth_year i.months_btwn_surveys_cat , vce(robust)	
	eststo _est_`var'_y`i': margins, dydx(treat_high treat_low) post

	matrix Y[`i',1] =  _b[treat_high]
	matrix Y[`i',2] =  _se[treat_high]
	matrix Y[`=`i'+1',1] =  _b[treat_low]
	matrix Y[`=`i'+1',2] =  _se[treat_low]	
	local i = `i' + 2
	drop treat_high treat_low
    }
  

logit  working_ui_12 treatXc1_nohs treatXc1_hs treatXc2_nohs treatXc2_hs c1_nohs c1_hs c2_nohs c2_hs  working_ui $controls i.cohortXmonth_year i.months_btwn_surveys_cat , vce(robust)	
eststo _est_edcoh_y: margins, dydx(treatXc1_nohs treatXc1_hs treatXc2_nohs treatXc2_hs) post

 	matrix Y[`i',1] =  _b[treatXc1_nohs]
	matrix Y[`i',2] =  _se[treatXc1_nohs]
  	matrix Y[`=`i'+1',1] =  _b[treatXc1_hs]
	matrix Y[`=`i'+1',2] =  _se[treatXc1_hs]
	matrix Y[`=`i'+2',1] =  _b[treatXc2_nohs]
	matrix Y[`=`i'+2',2] =  _se[treatXc2_nohs]
	matrix Y[`=`i'+3',1] =  _b[treatXc2_hs]
	matrix Y[`=`i'+3',2] =  _se[treatXc2_hs]
  
  
  
  
 
	matrix Y = Y'
	matrix list Y
	coefplot matrix(Y),  se(2) ///
	mcolor(LEOBlue) ciopts(lcolor(LEOBlue)) ///
	xline(0) xtitle("Subgroup Treatment Effect") xlabel(-.3(.1).7)
	graph export "hetro_graph_y3.png", replace





***********************************
* Table
******************************
qui gen x = .
qui gen const = 1
qui gen total = .
qui gen interact = .
qui gen p_diff = .
eststo clear
 	eststo clear 	
	qui reg working_y1_com const
	eststo _filler
	
	esttab _filler _filler _filler _filler _filler _filler _filler _filler ///
	using "ADM - Subgroup Effects.tex", replace ///
	keep(const) drop(const) ///
	nogaps nonotes noobs b(a2) frag
		

foreach var in    nohs_clean hs_clean cohort1 cohort2 c1_nohs c1_hs c2_nohs c2_hs {
	replace `var' = `var'*treatment_final
}

		* 1 year employment
		logit working_y1_com treatment_final working_bl_com $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
		eststo _b1: margins, dydx(treatment_final) post
		logit working_y1_com cohort1 cohort2  working_bl_com $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
		eststo _b2: margins, dydx(cohort1 cohort2 ) post
		logit working_y1_com nohs_clean hs_clean working_bl_com $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
		eststo _b3: margins, dydx(nohs_clean hs_clean) post
		logit working_y1_com c1_nohs c1_hs c2_nohs c2_hs working_bl_com $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
		eststo _b4: margins, dydx(c1_nohs c1_hs c2_nohs c2_hs) post
		
		
		* 3 year employment
		logit working_ui_12 treatment_final working_ui $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
		eststo _b5: margins, dydx(treatment_final) post
		logit working_ui_12 cohort1 cohort2  working_ui $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
		eststo _b6: margins, dydx(cohort1 cohort2 ) post
		logit working_ui_12 nohs_clean hs_clean working_ui $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
		eststo _b7: margins, dydx(nohs_clean hs_clean) post
		logit working_ui_12 c1_nohs c1_hs c2_nohs c2_hs working_ui  $controls i.cohortXmonth_year i.months_btwn_surveys_cat, vce(robust)
		eststo _b8: margins, dydx(c1_nohs c1_hs c2_nohs c2_hs) post
		

	esttab _b* using ///
	"ADM - Subgroup Effects.tex", append ///
	keep(treatment_final  nohs_clean hs_clean cohort1 cohort2 c1_nohs c1_hs c2_nohs c2_hs)  se ///
	cells("b(star fmt(%3.2f))" se(par fmt(%3.2f) )) ///
	starlevel(* 0.10 ** 0.05 *** 0.01)  ///
	collabels(none) nonum noobs nogaps nomtitle nonotes nolines frag
/*

set seed 880004	
scalar reps = 1000

use  "${ui}/dta_clean/ui_panel_2023.dta", clear
cd "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim/Figures/"
gen cohortXmonth_year = month_year * 10 + cohort


global controls female quarterly_r_earnings married_clean white black other hispanic ///
 college_clean some_college_clean nohs_clean hs_clean
global fe cohortXmonth_year randomization_group months_btwn_surveys_cat

/*
Make a sub-group effects ladder plot figure for 1 year and 3 year employment effects
Black/Not Black, Male/Female, Single mom vs not (female, child under 18, no spouse present); above/below median age, pre/post COVID, cohort, HS, cohortXHS, abadie RSS split (in that order)
Move Table 5 to appendix; and update writing of het effects throughout the paper and the referee responses
*/

label var black "Black"
gen not_black = (black == 0)
label var not_black "Not Black"
label var female "Female"
gen male = (female == 0)
label var male "Male"
gen single_mom = (female == 1) & (num_workage_adults == 1) & (num_kids > 0)
label var single_mom "Single Mom"
gen not_single_mom = (single_mom == 0)
label var not_single_mom "Not Single Mom"
sum age, d
gen abov_med_age = (age > r(p50))
label var abov_med_age "Above Median Age"
gen below_med_age = (abov_med_age == 0)
label var below_med_age "Below Median Age"
gen day_bline = date(baselinedate, "MDY")
format day_bline %td
gen post_covid = day_bline > 22006
label var post_covid "Enrolled Post Covid"
gen pre_covid = (post_covid == 0)
label var pre_covid "Enrolled Pre Covid"
gen cohort1 = (cohort == 1)
label var cohort1 "Cohort 1"
gen cohort2 = (cohort == 2)
label var cohort2 "Cohort 2"
label var nohs_clean "No High School"
gen hs_clean = (nohs_clean == 0)
label var hs_clean "High School"

gen c1_nohs = (cohort1 == 1 & nohs_clean == 1)
gen c1_hs   = (cohort1 == 1 & hs_clean   == 1)
gen c2_nohs = (cohort2 == 1 & nohs_clean == 1)
gen c2_hs   = (cohort2 == 1 & hs_clean   == 1)
label var c1_nohs "Cohort 1, No High School"
label var c1_hs "Cohort 1, High School"
label var c2_nohs "Cohort 2, No High School"
label var c2_hs "Cohort 2, High School"



global cats black not_black female male single_mom not_single_mom abov_med_age below_med_age   nohs_clean hs_clean cohort1 cohort2 c1_nohs c1_hs c2_nohs c2_hs
