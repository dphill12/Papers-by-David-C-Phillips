*************************************************************************
*btos_snap_tanf.do
*
*Author: David Phillips
*
*Date of original: 1/7/2020
*
*Purpose: Merge OTDA data on TANF and PA receipt to baseline information
*         and then measure treatment effects
*
*************************************************************************

global datadir_otda /afs/crc.nd.edu/group/LEO/BTOS_OTDA_DATA/Raw-Data/Raw Data from OTDA (12.2.19)
*M:\Rochester\Raw-Data\Raw Data from OTDA (12.2.19)
global maindir /afs/crc.nd.edu/group/LEO/BTOS_OTDA_DATA/De-Identified
*M:\Rochester\De-identified\

global controls female quarterly_r_earnings married_clean ///
white black other hispanic nohs_clean hs_GED_clean some_college_clean college_clean 
global fe month_year  randomization_group

*Load and clean OTDA data
clear
cd "$datadir_otda"

import excel using Bridges_to_Success_Match.FINAL2.xlsx

scalar counter = 0
foreach var of varlist * {
	rename `var' var`=counter'
	scalar counter = counter + 1
}

keep in 6/l

rename var0 otda_id
forvalues x = 1(1)12 {
	rename var`=`x'*2-1' pa`x'
	rename var`=`x'*2' snap`x'
}

qui gen match_status = ""
qui replace match_status = "Not Matched" if pa1 == "COULD NOT CONFIRM A MATCH WITH THE INFORMATION PROVIDED"
qui replace match_status = "Match But No Payments" if pa1 == "NO PA OR SNAP PAYMENTS WITHIN 12 MONTHS OF INDUCTION DATE"
qui replace match_status = "Matched With Payments" if regexm(pa1,"^[0-9]+[\.]*[0-9]*$")

forvalues x = 12(-1)1 {
	*replace snap`x' = "0" if match_status == "Match But No Payments" 
	*replace snap`x' = "" if match_status == "Not Matched" 
	*replace pa`x' = "0" if match_status == "Match But No Payments" 
	*replace pa`x' = "" if match_status == "Not Matched" 
	qui replace snap`x' = "0" if match_status == "Match But No Payments" 
	qui replace snap`x' = "0" if match_status == "Not Matched" 
	qui replace pa`x' = "0" if match_status == "Match But No Payments" 
	qui replace pa`x' = "0" if match_status == "Not Matched"
	destring snap`x', replace
	destring pa`x', replace
}
destring otda_id, replace

***************************************************************************
* Tables
***************************************************************************
* Merge on Baseline characteristics
*Merging on baseline data    (DOUBLE CHECK THIS FILE IS CONSISTENT WITH OTHERS IN USE LATER)
* We want the any snap, amount of snap, any tanf, any tanf

* THis section is to produce presults in section 8 part A od the PAP
gen x = .
gen const = 1
gen total = .
cd "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/Tim/Figures"
foreach var in pa snap {
	gen `var'_any = (`var'1 >0)
	gen `var'_any_y1 = (`var'12 >0)
	gen `var'_amt = `var'1
	gen `var'_amt_y1 = `var'12
}


label var pa_any "PA"
label var pa_amt "PA"
label var snap_any "SNAP"
label var snap_amt "SNAP"

gen benefits_any = (pa_any == 1 | snap_any == 1)
gen benefits_any_y1 = (pa_any_y1 == 1 | snap_any_y1 == 1)
gen benefits_amt = (pa_amt + snap_amt)
gen benefits_amt_y1 = (pa_amt_y1 + snap_amt_y1)

label var benefits_any "Total Benefits"
label var benefits_amt "Total Benefits"


global otda_outcomes snap_any pa_any benefits_any snap_amt pa_amt    benefits_amt

merge m:1 otda_id using "$maindir/DTA Files/OTDA_bline_with_key.dta", keepusing(FamilyID) nogen keep(3)
merge 1:1 FamilyID using "/afs/crc.nd.edu/group/LEO/ENCRYPT_AT_REST/Rochester_RA/De-Identified/DTA Files/Complete Clean.dta", nogen keep(3) keepusing( $fe $controls Program experian_id)

preserve
keep experian_id
save "${tim}/samples/OTDA.dta", replace
restore

gen treat = (Program == "TREATMENT")

	qui reg pa_any const
		eststo _filler
		esttab _filler _filler _filler _filler _filler using "ADM - OTDA.tex", replace ///
		keep(const) drop(const) ///
		nogaps nonotes noobs  b(a2) frag posthead(\hline \textbf{OTDA} \\ ) ///
		mtitles("Sample Size" "Full Sample" "Treatment" "Control" "Adj. Diff.")
				
	*Loop through and fill in table 
			foreach var in $otda_outcomes {
			eststo clear	
			quietly replace x = const
			local head
			qui mdesc `var'_y
			quietly replace total = r(total)-r(miss)
			eststo _b0: qui reg total x , nocons
			eststo _b1: qui reg `var'_y x, nocons r 
			eststo _b2: qui reg `var'_y x if treat == 1, nocons r			
			eststo _b3: qui reg `var'_y x if treat == 0, nocons r				
			quietly replace x = treat
			eststo _b4:  reghdfe `var'_y1 x `var' $controls , absorb($fe) vce(robust)
			
			if "`var'" == "pa_amt" | "`var'" == "snap_amt" | "`var'" ==  "benefits_amt" {
				local dig = 0
			}
			if "`var'" != "pa_amt" & "`var'" != "snap_amt" & "`var'" !=  "benefits_amt" {
				local dig = 2
			}
			if "`var'" == "snap_any" {
				local head prehead("\textit{Received Any}:\\")
			}
			if "`var'" == "snap_amt" {
				local head prehead("\textit{Amount (\\\$) Received}:\\")
			}
			esttab _b* using "ADM - OTDA.tex", append ///
			keep(x) varlabels(x "`: var label `var''") se ///
			cells("b(star pattern(0 0 0 0 1) fmt(%4.`dig'f)) b(pattern(0 1 1 1 0) fmt(%4.`dig'f)) b(pattern(1 0 0 0 0) fmt(%4.0f))" se(par fmt(%4.`dig'f) pattern(0 0 0 0 1))) ///
			starlevel(* 0.10 ** 0.05 *** 0.01) collabels(none) nodepvars nonum nomtitle nogaps nonotes nolines frag noobs `head' 
		}
