use "${dta_loc}/Complete Clean", clear
gen cohort = 1
append using "${dta_loc}/Complete Clean C2", force
replace cohort = 2 if missing(cohort)
cd $Figures


***************************************************************
* Baseline Balance Tables Setup
***************************************************************

global balance 	working_clean working_ui quarterly_r_earnings quarterly_earnings_con nohs_clean ///
		married_clean age has_kids_clean female hispanic white black other
global goals 	primary_goal_housing_clean primary_goal_family_clean primary_goal_health_clean ///
		primary_goal_networks_clean primary_goal_edu_clean primary_goal_employment_clean primary_goal_finances_clean 

label var working_clean "Employed at Baseline"
label var quarterly_r_earnings "Quarterly Earnings (\\\$)"
gen quarterly_earnings_con = quarterly_r_earnings 
replace quarterly_earnings_con = . if quarterly_earnings_con == 0
label var quarterly_earnings_con "Quarterly Earnings (\\\$, Employed)"
label var nohs_clean "No High School/GED"
label var age "Age"
label var married_clean "Married"
label var has_kids_clean "Has Children"
label var female "Female"
label var hispanic "Hispanic"
label var white "White"
label var black "Black"
label var other "Other Race"


label var primary_goal_housing_clean "-Housing"
label var primary_goal_family_clean "-Family"
label var primary_goal_health_clean "-Health"
label var primary_goal_networks_clean "-Networks"
label var primary_goal_edu_clean "-Education"
label var primary_goal_employment_clean "-Employment"
label var primary_goal_finances_clean "-Finances"

gen primary_goal_missing_clean = (missing(primarygoal))
label var primary_goal_missing_clean "-Missing"

merge m:1 experian_id using "${ui}/dta_clean/ui_panel_2023.dta", keepusing(working_ui) nogen
label var working_ui "Employed Quarter Prior"

gen x = 1
gen total = . 
gen const = 1
gen p_diff = .

***************************************************************
* Table 1
***************************************************************
		qui reg treatment_final x 
		eststo _filler
		esttab _filler _filler _filler _filler _filler _filler _filler using "balance_full.tex", replace ///
		keep(x) drop(x) varlabels(x "`: var label `var''")  ///
		mtitles("Urban" "Rochester" "Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value") ///
		frag collabels(none) nonotes  nogaps noobs
		preserve
append using "${tim}/comparison_demographics.dta"
	replace const = 1
	qui replace working_ui = 0 if missing(treatment_final)
		foreach var of varlist $balance { 
		
		eststo clear
		qui replace x = const
		eststo _c1: qui reg `var' x if urban == 1 , nocons
		eststo _c2: qui reg `var' x if rochester == 1 , nocons
		
		eststo _b1: qui reg `var' x if !missing(treatment_final), nocons
		eststo _b2: qui reg `var' x if treatment_final == 1, nocons
		eststo _b3: qui reg `var' x if treatment_final == 0, nocons
		qui replace x = treatment_final
		eststo _b4: qui reghdfe `var' x, absorb(randomization_group)
		qui replace  p_diff = 2*(1-normal(abs(_b[x] / _se[x])))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		if "`var'" != "age" & "`var'" != "quarterly_earnings_con" & "`var'" != "quarterly_r_earnings" {
		local dig = 2
		local type f
		}
		if "`var'" == "age" {
		local dig = 1
		local type f
		}
		if "`var'" == "quarterly_earnings_con" | "`var'" == "quarterly_r_earnings" {
		local dig = 0
		local type fc
		}
	
		qui esttab _c1 _c2 _b1 _b2 _b3 _b4 _b5 using "balance_full.tex", append ///
		keep(x) varlabels(x "`: var label `var''")  ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern(1 1 1 1 1 0 0)  fmt(%9.`dig'fc)) b(pattern(0 0 0 0 0 0 1)  fmt(%9.2fc)) b(star pattern(0 0 0 0 0 1 0) fmt(%9.`dig'fc))") ///
		nonum nonotes nolines nogaps noobs nomtitles 
		}
		
		local counter = 1
		foreach var of varlist $goals { 
		local head
		eststo clear
		qui replace x = 1
		eststo _c1: qui reg const  treatment_final  , nocons
		eststo _c2: qui reg  const treatment_final , nocons
		eststo _b1: qui reg `var' x, nocons
		eststo _b2: qui reg `var' x if treatment_final == 1, nocons
		eststo _b3: qui reg `var' x if treatment_final == 0, nocons
		qui replace x = treatment_final
		eststo _b4: qui reghdfe `var' x, absorb(randomization_group)
		qui replace  p_diff = 2*(1-normal(abs(_b[x] / _se[x])))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		if `counter' == 1 {
			local heading prehead("Primary Goal:\\")
		}
		if `counter' != 1 {
			local heading 
		}
		
		esttab _c1 _c2 _b1 _b2 _b3 _b4 _b5 using "balance_full.tex", append ///
		keep(x ) varlabels(x "`: var label `var''") drop() ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern(1 1 1 1 1 0 1)  fmt(%4.2f)) b(star pattern(0 0 0 0 0 1 0) fmt(%4.2f))") ///
		nonum nonotes nolines nogaps noobs nomtitles `heading'
		
		local counter = `counter' + 1
			}	
		eststo _d2: qui reg has_kids_clean nohs_clean if rochester == 1 , nocons
		eststo _d1: qui reg has_kids_clean nohs_clean if urban == 1 , nocons
		esttab _d1 _d2 _b1 _b2 _b3  using "balance_full.tex", append ///
		keep(x) drop(x) frag collabels(none) ///
		nonum nonotes nolines nogaps nomtitles nostar stats(N, fmt(%9.0fc)) 
		restore
		

/* *****************************************************************************
Table A.1 - Compare cohorts
*/ *****************************************************************************


	gen cohort_place = (cohort == 1)
		reg treatment_final x
		eststo _filler
		esttab _filler _filler _filler _filler  _filler using "balance_cohort_compare.tex", replace ///
		keep(x) drop(x) varlabels(x "`: var label `var''")  ///
		mtitles("Full Sample" "Cohort 1" "Cohort 2" "Adj. Diff." "P-Value") ///
		frag collabels(none) nonotes  nogaps noobs

	
		foreach var of varlist $balance $goals  { 
		local head
		eststo clear
		replace x = const
		eststo _b1: qui reg `var' x, nocons
		eststo _b2: qui reg `var' x if cohort == 1, nocons		
		eststo _b3: qui reg `var' x if cohort == 2, nocons
		qui replace x = cohort_place		
		eststo _b4: qui reg `var' x
		
		local beta_diff = _b[x]	
		local se_diff = _se[x]
		qui replace  p_diff = 2*(1-normal(abs(`beta_diff' / `se_diff')))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		
		if "`var'" != "age" & "`var'" != "quarterly_earnings_con" & "`var'" != "quarterly_r_earnings" {
		local dig = 2
		local type f
		}
		if "`var'" == "age" {
		local dig = 1
		local type f
		}
		if "`var'" == "quarterly_earnings_con" | "`var'" == "quarterly_r_earnings" {
		local dig = 0
		local type fc
		}
		if "`var'" == "primary_goal_housing_clean" {
			local head prehead("Primary Goal:\\")
		}
		esttab _b1 _b2 _b3 _b4 _b5 using "balance_cohort_compare.tex", append ///
		keep(x) varlabels(x "`: var label `var''")  ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern( 1 1 1 0 0)  fmt(%9.`dig'fc)) b(star pattern( 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 0 0 0 1)  fmt(%9.2fc))") ///
		nonum nonotes nolines nogaps noobs nomtitles `head'
	}
	
		esttab  _b1 _b2 _b3  using "balance_cohort_compare.tex", append ///
		keep(x) drop(x)  ///
		frag collabels(none) ///
		nonum nonotes nolines nogaps nomtitles starlevel(* 0.10 ** 0.05 *** 0.01)	

/* *****************************************************************************
Table A.2 - Attrition Sample
*/ *****************************************************************************

preserve

merge m:1 experian_id using "${tim}/samples/followup.dta"
		qui reg treatment_final x
		gen followup_yn = (_merge == 3)
		eststo _filler
		esttab _filler _filler _filler _filler  _filler using "balance_attrition.tex", replace ///
		keep(x) drop(x) varlabels(x "`: var label `var''")  ///
		mtitles("Full Sample" "Follow-Up" "No Follow-Up" "Adj. Diff." "P-Value") ///
		frag collabels(none) nonotes  nogaps noobs

		foreach var of varlist $balance $goals  { 
		local head
				eststo clear
		replace x = const
		eststo _b1: qui reg `var' x, nocons
		eststo _b2: qui reg `var' x if followup_yn == 1, nocons
		eststo _b3: qui reg `var' x if followup_yn == 0, nocons
		replace x = treatment_final		
		eststo _b4: qui reghdfe `var' x, absorb(randomization_group)
		qui replace  p_diff = 2*(1-normal(abs(_b[x] / _se[x])))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		
		if "`var'" != "age" & "`var'" != "quarterly_earnings_con" & "`var'" != "quarterly_r_earnings" {
		local dig = 2
		local type f
		}
		if "`var'" == "age" {
		local dig = 1
		local type f
		}
		if "`var'" == "quarterly_earnings_con" | "`var'" == "quarterly_r_earnings" {
		local dig = 0
		local type fc
		}
			if "`var'" == "primary_goal_housing_clean" {
			local head prehead("Primary Goal:\\")
		}	
		esttab _b1 _b2 _b3 _b4 _b5 using  "balance_attrition.tex", append ///
		keep(x) varlabels(x "`: var label `var''")  ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern( 1 1 1 0 0)  fmt(%9.`dig'f)) b(star pattern( 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 0 0 0 1)  fmt(%4.2f))") ///
		nonum nonotes nolines nogaps noobs nomtitles `head'
		}
		esttab  _b1 _b2 _b3  using "balance_attrition.tex", append ///
		keep(x) drop(x)  ///
		frag collabels(none) ///
		nonum nonotes nolines nogaps nomtitles 
restore
	


/* *****************************************************************************
Table A.3 - Follow up Survey Sample
*/ *****************************************************************************
preserve
drop if missing(experian_id)
merge 1:1 experian_id using "${tim}/samples/followup.dta", keep(3)
		qui reg treatment_final x
		eststo _filler
		esttab _filler _filler _filler _filler  _filler using "balance_followup.tex", replace ///
		keep(x) drop(x) varlabels(x "`: var label `var''")  ///
		mtitles("Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value") ///
		frag collabels(none) nonotes  nogaps noobs

	foreach var of varlist $balance $goals  { 
		local head
		eststo clear
		replace x = const
		eststo _b1: qui reg `var' x, nocons
		eststo _b2: qui reg `var' x if treatment_final == 1, nocons
		eststo _b3: qui reg `var' x if treatment_final == 0, nocons
		replace x = treatment_final		
		eststo _b4: qui reghdfe `var' x, absorb(randomization_group)
		qui replace  p_diff = 2*(1-normal(abs(_b[x] / _se[x])))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		
		if "`var'" != "age" & "`var'" != "quarterly_earnings_con" & "`var'" != "quarterly_r_earnings" {
		local dig = 2
		local type f
		}
		if "`var'" == "age" {
		local dig = 1
		local type f
		}
		if "`var'" == "quarterly_earnings_con" | "`var'" == "quarterly_r_earnings" {
		local dig = 0
		local type fc
		}
		if "`var'" == "primary_goal_housing_clean" {
			local head prehead("Primary Goal:\\")
		}
		esttab _b1 _b2 _b3 _b4 _b5 using  "balance_followup.tex", append ///
		keep(x) varlabels(x "`: var label `var''")  ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern( 1 1 1 0 0)  fmt(%9.`dig'fc)) b(star pattern( 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 0 0 0 1)  fmt(%4.2f))") ///
		nonum nonotes nolines nogaps noobs nomtitles `head'
	}
	
		esttab  _b1 _b2 _b3  using "balance_followup.tex", append ///
		keep(x) drop(x)  ///
		frag collabels(none) ///
		nonum nonotes nolines nogaps nomtitles 
restore

/* *****************************************************************************
Table A.4 - UI Sample
*/ *****************************************************************************

preserve
drop if missing(experian_id)
merge 1:1 experian_id using "${tim}/samples/ui.dta", keep(3)
		qui reg treatment_final x
		eststo _filler
		esttab _filler _filler _filler _filler _filler using "balance_ui.tex", replace ///
		keep(x) drop(x) varlabels(x "`: var label `var''")  ///
		mtitles("Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value") ///
		frag collabels(none) nonotes  nogaps noobs

	foreach var of varlist $balance $goals  { 
		local head
		eststo clear
		replace x = const
		eststo _b1: qui reg `var' x, nocons
		eststo _b2: qui reg `var' x if treatment_final == 1, nocons
		eststo _b3: qui reg `var' x if treatment_final == 0, nocons
		replace x = treatment_final		
		eststo _b4: qui reghdfe `var' x, absorb(randomization_group)
		
		local beta_diff = _b[x]	
		local se_diff = _se[x]
		qui replace  p_diff = 2*(1-normal(abs(`beta_diff' / `se_diff')))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		
		if "`var'" != "age" & "`var'" != "quarterly_earnings_con" & "`var'" != "quarterly_r_earnings" {
		local dig = 2
		}
		if "`var'" == "age" {
		local dig = 1
		}
		if "`var'" == "quarterly_earnings_con" | "`var'" == "quarterly_r_earnings" {
		local dig = 0
		}
		if "`var'" == "primary_goal_housing_clean" {
			local head prehead("Primary Goal:\\")
		}
		esttab _b1 _b2 _b3 _b4 _b5 using  "balance_ui.tex", append ///
		keep(x) varlabels(x "`: var label `var''")  ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern( 1 1 1 0 0)  fmt(%9.`dig'fc)) b(star pattern( 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 0 0 0 1)  fmt(%4.2f))") ///
		nonum nonotes nolines nogaps noobs nomtitles `head'
	}
	
		esttab  _b1 _b2 _b3  using "balance_ui.tex", append ///
		keep(x) drop(x)  ///
		frag collabels(none) ///
		nonum nonotes nolines nogaps nomtitles 
restore



/* *****************************************************************************
Table A.5 - Follow up Survey or UI Sample
*/ *****************************************************************************

preserve
drop if missing(experian_id)
merge 1:1 experian_id using "${tim}/samples/followup_ui.dta", keep(3)
		reg treatment_final x
		eststo _filler
		esttab _filler _filler _filler _filler _filler using "balance_followup_ui.tex", replace ///
		keep(x) drop(x) varlabels(x "`: var label `var''")  ///
		mtitles("Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value") ///
		frag collabels(none) nonotes  nogaps noobs

		foreach var of varlist $balance $goals  { 
		local head
		eststo clear
		replace x = const
		eststo _b1: qui reg `var' x, nocons
		eststo _b2: qui reg `var' x if treatment_final == 1, nocons
		eststo _b3: qui reg `var' x if treatment_final == 0, nocons
		replace x = treatment_final		
		eststo _b4: qui reghdfe `var' x, absorb(randomization_group) vce(robust)
		
		local beta_diff = _b[x]	
		local se_diff = _se[x]
		qui replace  p_diff = 2*(1-normal(abs(`beta_diff' / `se_diff')))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		
		if "`var'" != "age" & "`var'" != "quarterly_earnings_con" & "`var'" != "quarterly_r_earnings" {
		local dig = 2
		local type f
		}
		if "`var'" == "age" {
		local dig = 1
		local type f
		}
		if "`var'" == "quarterly_earnings_con" | "`var'" == "quarterly_r_earnings" {
		local dig = 0
		local type fc
		}
		if "`var'" == "primary_goal_housing_clean" {
			local head prehead("Primary Goal:\\")
		}	
		esttab  _b1 _b2 _b3 _b4 _b5 using "balance_followup_ui.tex", append ///
		keep(x) varlabels(x "`: var label `var''")  ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern(1 1 1 0 0)  fmt(%9.`dig'fc)) b(star pattern(0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 0 0 0 1)  fmt(%4.2f))" ) ///
		nonum nonotes nolines nogaps noobs nomtitles `head'
	}
	
		esttab  _b1 _b2 _b3  using "balance_followup_ui.tex", append ///
		keep(x) drop(x)  ///
		frag collabels(none) ///
		nonum nonotes nolines nogaps nomtitles 
restore

/* *****************************************************************************
Table A.6 - Experian Sample
*/ *****************************************************************************

preserve
drop if missing(experian_id)
merge 1:1 experian_id using "${tim}/samples/Experian.dta", keep(3)
		qui reg treatment_final x
		eststo _filler
		esttab _filler _filler _filler _filler _filler using "balance_experian.tex", replace ///
		keep(x) drop(x) varlabels(x "`: var label `var''")  ///
		mtitles("Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value") ///
		frag collabels(none) nonotes  nogaps noobs

	
		foreach var of varlist $balance $goals  { 
		local head
		eststo clear
		di "`var'"
		replace x = const
		eststo _b1: qui reg `var' x, nocons
		eststo _b2: qui reg `var' x if treatment_final == 1, nocons
		eststo _b3: qui reg `var' x if treatment_final == 0, nocons
		replace x = treatment_final		
		eststo _b4: qui reghdfe `var' x, absorb(randomization_group)
		
		local beta_diff = _b[x]	
		local se_diff = _se[x]
		qui replace  p_diff = 2*(1-normal(abs(`beta_diff' / `se_diff')))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		
		if "`var'" != "age" & "`var'" != "quarterly_earnings_con" & "`var'" != "quarterly_r_earnings" {
		local dig = 2
		}
		if "`var'" == "age" {
		local dig = 1
		}
		if "`var'" == "quarterly_earnings_con" | "`var'" == "quarterly_r_earnings" {
		local dig = 0
		}
		if "`var'" == "primary_goal_housing_clean" {
			local head prehead("Primary Goal:\\")
		}
		qui esttab  _b1 _b2 _b3 _b4 _b5 using "balance_experian.tex", append ///
		keep(x) varlabels(x "`: var label `var''")  ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern( 1 1 1 0 0)  fmt(%9.`dig'fc)) b(star pattern( 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 0 0 0 1)  fmt(%4.2f))") ///
		nonum nonotes nolines nogaps noobs nomtitles   `head'
	}
	
		esttab  _b1 _b2 _b3  using "balance_experian.tex", append ///
		keep(x) drop(x)  ///
		frag collabels(none) ///
		nonum nonotes nolines nogaps nomtitles starlevel(* 0.10 ** 0.05 *** 0.01)	
restore

/* *****************************************************************************
Table A.7 - OTDA sample
*/ *****************************************************************************

preserve
drop if missing(experian_id)
merge 1:1 experian_id using "${tim}/samples/OTDA.dta", keep(3)
		reg treatment_final x
		eststo _filler
		esttab _filler _filler _filler _filler _filler using "balance_otda.tex", replace ///
		keep(x) drop(x) varlabels(x "`: var label `var''")  ///
		mtitles("Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value") ///
		frag collabels(none) nonotes  nogaps noobs

		foreach var of varlist $balance $goals  { 
		local head
				eststo clear
		replace x = const
		eststo _b1: qui reg `var' x, nocons
		eststo _b2: qui reg `var' x if treatment_final == 1, nocons
		eststo _b3: qui reg `var' x if treatment_final == 0, nocons
		replace x = treatment_final		
		eststo _b4: qui reghdfe `var' x, absorb(randomization_group)
		qui replace  p_diff = 2*(1-normal(abs(_b[x] / _se[x])))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		
		if "`var'" != "age" & "`var'" != "quarterly_earnings_con" & "`var'" != "quarterly_r_earnings" {
		local dig = 2
		local type f
		}
		if "`var'" == "age" {
		local dig = 1
		local type f
		}
		if "`var'" == "quarterly_earnings_con" | "`var'" == "quarterly_r_earnings" {
		local dig = 0
		local type fc
		}
		if "`var'" == "primary_goal_housing_clean" {
			local head prehead("Primary Goal:\\")
		}
		esttab _b1 _b2 _b3 _b4 _b5 using  "balance_otda.tex", append ///
		keep(x) varlabels(x "`: var label `var''")  ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern( 1 1 1 0 0)  fmt(%9.`dig'fc)) b(star pattern( 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 0 0 0 1)  fmt(%4.2f))") ///
		nonum nonotes nolines nogaps noobs nomtitles `head'
	}
	
		esttab  _b1 _b2 _b3  using "balance_otda.tex", append ///
		keep(x) drop(x)  ///
		frag collabels(none) ///
		nonum nonotes nolines nogaps nomtitles 
restore





/* *****************************************************************************
Table A.8 - Infutor Sample
*/ *****************************************************************************

preserve
drop if missing(experian_id)
merge 1:1 experian_id using "${tim}/samples/Infutor.dta", keep(3) nogen
		reg treatment_final x
		eststo _filler
		esttab _filler _filler _filler _filler _filler using "balance_infutor.tex", replace ///
		keep(x) drop(x) varlabels(x "`: var label `var''")  ///
		mtitles("Full Sample" "Treatment" "Control" "Adj. Diff." "P-Value") ///
		frag collabels(none) nonotes  nogaps noobs

	
	foreach var of varlist $balance $goals  { 
		local head
		eststo clear
		replace x = const
		eststo _b1: qui reg `var' x, nocons
		eststo _b2: qui reg `var' x if treatment_final == 1, nocons
		eststo _b3: qui reg `var' x if treatment_final == 0, nocons
		qui replace x = treatment_final		
		eststo _b4: qui reghdfe `var' x, absorb(randomization_group)
		
		local beta_diff = _b[x]	
		local se_diff = _se[x]
		qui replace  p_diff = 2*(1-normal(abs(`beta_diff' / `se_diff')))
		qui replace x = const
		eststo _b5: qui reg p_diff x, nocons
		
		
		if "`var'" != "age" & "`var'" != "quarterly_earnings_con" & "`var'" != "quarterly_r_earnings" {
		local dig = 2
		local type f
		}
		if "`var'" == "age" {
		local dig = 1
		local type f
		}
		if "`var'" == "quarterly_earnings_con" | "`var'" == "quarterly_r_earnings" {
		local dig = 0
		local type fc
		}
		if "`var'" == "primary_goal_housing_clean" {
		local head prehead("Primary Goal:\\")
		}
		esttab _b1 _b2 _b3 _b4 _b5 using  "balance_infutor.tex", append ///
		keep(x) varlabels(x "`: var label `var''")  ///
		frag collabels(none) starlevel(* 0.10 ** 0.05 *** 0.01) /// 
		cells(" b(pattern( 1 1 1 0 0)  fmt(%9.`dig'fc)) b(star pattern( 0 0 0 1 0) fmt(%9.`dig'fc)) b(pattern(0 0 0 0 1)  fmt(%4.2f))") ///
		nonum nonotes nolines nogaps noobs nomtitles `head'
	}
		esttab  _b1 _b2 _b3  using "balance_infutor.tex", append ///
		keep(x) drop(x)  ///
		frag collabels(none) ///
		nonum nonotes nolines nogaps nomtitles 	
restore


